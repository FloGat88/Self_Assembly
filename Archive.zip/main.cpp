//
//  main.cpp
//  Self_Assembly
//
//  Created by Florian Gartner on 30/05/17.
//  Copyright © 2017 Florian Gartner. All rights reserved.
//

#include "System.hpp"

// System parameter (when using ParameterSweep() or Hyper_Sweep() the parameters that are sweeped over are varied independently of the value fixed here)
short L = 10;      // Linear extension of the structures
short N = 1000 * (HOMOGENIZATION==true ? pow(L,DIMENSION) : 1);     // particle number N per species; if HOMOGENIZATION==true (i.e. there is only one species and structures are built homogeneously) it is reasonable to multiply by the size of the target sturctures in order to build a constant number (here 1000) of structures both in the homogeneous and the heterogeneous case
Float alpha = 1e14;     // activation or influx rate alpha. Constant influx of particles at rate N*alpha (if CONSTANT_DELIVERY == true) or influx with per capita activation rate alpha per inactive particle (exponential influx, if CONSTANT_DELIVERY == false) is ignored if START_INACTIVE==false  // for example, choose alpha = N*0.000005 for L=10 and DIMENSION=2 (SCENARIO=2)
Float mu = 0.001;     // dimerization rate;  (SCENARIO=1) // for example, choose mu = 0.00068 for L=10 and DIMENSION=2 (SCENARIO=1); if SCENARIO!=1 choose mu=1.0
Float nu = 1.0;     // attachment rate (set this to 1)
Float detachment_parameter = 0.;    //  per default is interpreted as the detachment rate delta_1 at which particles with a single bond detach from the structures. Alternatively can be interpreted as the binding energy E_B such that the binding Rates are given by delta_n = A*exp(-n*E_B) see definition of detachment_parameters[] in the constructor in System.hpp; is ignored if DETACHMENT==false  // for example, choose detachment_parameter = N*156.0 for L=10 and DIMENSION=2 (SCENARIO=0)
Float Delta_T = 0.;     // time interval between successive bursts for the Jis_Scenario; is ignored if JIS_2D == false.   // for example, choose Delta_T = 220./N for L=10 and DIMENSION=2 (SCENARIO=3)
short stat = 10;      // sample size = number of independent runs that are averaged



// Do not alter the following parameters (these were used for additional investigations and follow-up projects not subject of the paper)
short n_bursts = 1;       // provide the number N of particles n_bursts times; N*n_bursts is total number of particles; the next burst is provided as soon as all particles of the previous burst are assembled. Usually should be fixed at 1.
short critical_size = 1;    // structures of a size smaller or equal critical_size decay into monomers at rate decay_rate.
Float decay_rate = 0.0;
Float add_para = 0.0;
Float nu_def = 0.0;      // rate at which defects occur in the 1D case.

// other global parameters
vector<Float> reaction_parameters;
RandonNumberGenerator rng;


// interface for parallelization; enable parallelization by uncommenting the macro PARALLELIZE in Preliminary.hpp
void Simulate_parallel(short L_, short N_, short n_bursts_, short critical_size_, Float activation_parameter_, Float nucleation_parameter_, Float reaction_parameter_, Float wrong_reaction_parameter_, Float decay_parameter_, Float detachment_parameter_, Float Delta_T, float parameter, /*--simulate input---*/ short times, short comp_stat, Float* yield, Float* variance, double* T, array<Float,3>* yield_advanced, double* T50, double* T90)  {
    RandonNumberGenerator rng_parallel;
    System system(L_,N_,n_bursts_,critical_size_, activation_parameter_,nucleation_parameter_,reaction_parameter_,wrong_reaction_parameter_,decay_parameter_, detachment_parameter_,Delta_T,parameter,rng_parallel);
    if(HETEROGENEOUS_RATES)
        system.set_reaction_parameters(reaction_parameters);
    system.Simulate(times,comp_stat,yield,variance,T,yield_advanced,T50,T90);
}

// Run the simulation for the parameters specified above; average observables over 'stat' independent runs
void Run_Simulation()  {
#ifdef PARALLELIZE
    cout << "Run_Simulation() cannot be used with PARALLELIZE. Please comment out the macro in Preliminary.hpp" << endl;
    abort();
#endif
    
    Float yield, variance, T, T50, T90;
    array<Float,3> yield_advanced;
    System system(L,N,n_bursts,critical_size,alpha,mu,nu,nu_def,decay_rate,detachment_parameter,Delta_T,add_para,rng);
    system.Simulate(stat,-1,&yield,&variance,&T,&yield_advanced,&T50,&T90);         // first parameter: how many simulations are averaged; last parameter: Level of the complex statistics: -1: no complex statistics at all / 0: only the total number of complexes (active monomers and complete structures included) / 1: number of complexes for each complex size / 2: number of complexes for each complex type (size and species)
};


// perform a parameter sweep over the scenario control parameter (which is detachment_parameter, alpha, mu or Delta_T if SCENARIO==0, 1, 2 or 3 respectively). the sweep is specified in "parameter_vector" which may have to be adopted by hand in order to sweep the desired range in parameter space.
void ParameterSweep()  {
// when using parallelization, initialize all global parameters here in order to avoid overlap between different threads when initializing them in the constructor
    Len = L;
    L_ = L-1;
    LL = L*L;
    LL_ = L*(L-1);
    LLL = L*L*L;
    LLL_ = L*L*(L-1);
    
    vector<Float> parameter_vector;
    parameter_vector.reserve(80);
    
//////////////////////// determine the vector parameter_vector for the sweep here ////////////////
    for(Float w=-0.25; w<=+0.25; w+=0.05)   {
        // use the following if you already have a rough estimate of the expected parameter exponent and a value for the respective control parameter at S=100 (note that in the activation and reversible binding scenario the parameter is proportional to N); otherwise use the out-commented formula below instead where you fix the center of the sweep arbitrarily (might also have to adopt the step size w of the sweep in the for loop)
        Float para_offset = 0.00068;     // expected parameter value for a structure of size S=100; center of the sweeped range: for example for 2D structures (with non-periodic boundary): Rev: N*156.0; Dim: 0.00068; Act: N*0.000005; Jis: 220.0/N;
        Float para_exponent = -1.5;       // expected parameter exponent; for example for 2D structures: Rev: 1.33; Dim: -1.5; Act: -1.85; Jis: 0.96;
        Float target_structure_size = pow(L,DIMENSION);
        parameter_vector.push_back(para_offset * pow(10.,w) * pow(target_structure_size/100,para_exponent));
        
     // Float sweep_center = 0.0007*N;
    // parameter_vector.push_back(sweep_center * pow(10.,w));
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////

    vector<Float> yield(parameter_vector.size());
    vector<Float> variance(parameter_vector.size());
    vector<array<Float,3>> yield_advanced(parameter_vector.size());
    vector<double> T(parameter_vector.size());
    vector<double> T50(parameter_vector.size());
    vector<double> T90(parameter_vector.size());
#ifdef PARALLELIZE
    vector<thread> threads;
#endif
    short max_num_threads = 6;
    short start=0;
    short stop = min(max_num_threads,(short)parameter_vector.size());
    for( ; start!=stop; start=stop, stop = min(stop+max_num_threads,(short)parameter_vector.size()))  {   // do this so that a maximum number of max_num_threads threads is created (in order to consume not too much memory even if the parameter_vector is very long)
        for(short i=start; i<stop; ++i)  {
            if(SCENARIO==0)
                detachment_parameter = parameter_vector[i];
            else if(SCENARIO==1)
                mu = parameter_vector[i];
            else if(SCENARIO==2)
                alpha = parameter_vector[i];
            else if(SCENARIO==3)
                Delta_T = parameter_vector[i];
#ifndef PARALLELIZE
            System         system(L,N,n_bursts,critical_size,alpha,mu,nu,nu_def,decay_rate,detachment_parameter,Delta_T,0.0,rng);    // add_para    // parameter_vector[i];
            
            system.Simulate(stat,-1,&yield[i],&variance[i],&T[i],&yield_advanced[i],&T50[i],&T90[i]);      // for parameter description see "Run_Simulation"
        }
    }
#else
        threads.push_back(thread(Simulate_parallel,L,N,n_bursts,critical_size, alpha, mu, nu, nu_def, decay_rate, detachment_parameter, Delta_T, 0.0, stat, -1, &(yield[i]), &(variance[i]), &(T[i]), &(yield_advanced[i]), &(T50[i]), &(T90[i])));  // add_para
        }
        for (std::thread& t:threads)
            if (t.joinable())
                t.join();
    }
#endif
cout << "% L = " << L << ", N = " << N << ", stat = " << stat << ", max_num_steps = " << maximum_number_steps << endl;
    cout << "para = [";
    for(short i=0; i<parameter_vector.size()-1; ++i)
        cout << parameter_vector[i] << ", ";
    cout << parameter_vector.back() << "];" << endl;
        
    cout << "yield = [ ";
    for(short i=0; i<yield.size()-1; ++i)
        cout << yield[i] << ", ";
    cout << yield.back() << "];" << endl;
    
    cout << "variance = [ ";
    for(short i=0; i<variance.size()-1; ++i)
        cout << variance[i] << ", ";
    cout << variance.back() << "];" << endl;
    
    cout << "time = [ ";
    for(short i=0; i<T.size()-1; ++i)
        cout << T[i] << ", ";
    cout << T.back() << "];" << endl;
    
    if(ADVANCED_TIME_MEASUREMENT)  {
        cout << "T50 = [ ";
        for(short i=0; i<T50.size()-1; ++i)
            cout << T50[i] << ", ";
        cout << T50.back() << "];" << endl;
        
        cout << "T90 = [ ";
        for(short i=0; i<T90.size()-1; ++i)
            cout << T90[i] << ", ";
        cout << T90.back() << "];" << endl;
    }
};


// performs a series of ParameterSweeps for increasing system sizes. Can be used to determine the time complexity and control parameter exponent. Also prints the matlab commands that allow to determine the optimal parameter and minimal assembly time and allow to determine the corresponding exponents conveniently when copied to Matlab. If required the parameters like N, stat, max_num_steps etc. can be chosen individually for each target size as shown in the code.
void Hyper_Sweep()   {
    vector<short> L_vec;
    if(DIMENSION==1)
        L_vec = {25,50,100,200,400,700,1000};
    else if(DIMENSION==2)
        L_vec = {5,7,10,14,20,26,32};
    else if(DIMENSION==3)
        L_vec = {3,4,5,6,7,8,9,10};
 //   vector<short> N_vec = {10000,19600,40000,67600,103200};
 //   vector<long long> max_num_steps_vec = {(long long)2e8,(long long)3e8,(long long)5e8,(long long)1e9,(long long)2e9,(long long)5e9,(long long)10e9};
    for(short i=0; i<L_vec.size(); ++i)  {
        L = L_vec[i];
        N = 500 * (HOMOGENIZATION==true ? pow(L,DIMENSION) : 1);
  //      N = N_vec[i]
 //       maximum_number_steps = max_num_steps_vec[i];
        stat = DETACHMENT  ?  10 : 25;  //stat_vec[i];
        _TIC_;
        ParameterSweep();
        cout << "% ";           
        _TOC_;
// print matlab commands
        cout << "N = " << N << "; " << endl;
        cout << "para=para(T90~=-1);" << endl;
        cout << "T90=T90(T90~=-1);" << endl;
        if(i==0)  {
            cout << "T_min=N*min(T90);" << endl;
            cout << "p_opt=para(T90==min(T90));" << endl;
        }
        else  {
            cout << "T_min=[T_min, N*min(T90)];" << endl;
            cout << "p_opt=[p_opt, para(T90==min(T90))];" << endl;
        }
        cout << endl << endl << endl;
    }
};



int main() {
_TIC_;     // starts measurement of runtime
    
    Run_Simulation();             // Run the simulation for the parameters specified above; average observalbes over 'stat' independent runs
    
//    ParameterSweep();           // perform a parameter sweep over the scenario control parameter (which is      detachment_parameter, alpha, mu or Delta_T if SCENARIO==0, 1, 2 or 3 respectively). the sweep is specified in "parameter_vector" which may have to be adopted by hand in order to sweep the desired range in parameter space.
    
//    Hyper_Sweep();              // performs a series of ParameterSweeps for increasing system sizes. Can be used to determine the time complexity and control parameter exponent. Also prints the matlab commands that allow to determine the optimal parameter and minimal assembly time and allow to determine the corresponding exponents conveniently when copied to Matlab. If required the parameters like N, stat, max_num_steps etc. can be chosen individually for each target size as shown in the code.
    
_TOC_;     // terminates measurement of and prints the runtime
    return 0;
}

