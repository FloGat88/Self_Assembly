//
//  System.hpp
//  Self_Assembly
//
//  Created by Florian Gartner on 30/05/17.
//  Copyright © 2017 Florian Gartner. All rights reserved.
//

#ifndef System_hpp
#define System_hpp

#include "Preliminary.hpp"


constexpr short SCENARIO = 1;          // choose the scenario: 0=REV; 1=DIM; 2=ACT; 3=JIS;
constexpr short DIMENSION = 2;          // dimension of the structure
constexpr bool START_INACTIVE = (SCENARIO==2);      // start with all particles in inactive state (true) or active state (false); if JIS_MULTI_DIM is alse enabled START_INACTIVE provides each JIS burst as burst of inactive particles otherwise as burst of active particles
constexpr bool WRONG_BINDING = false;       // should be set to false
constexpr bool PERIODIC_BOUNDARY = false;    // periodic boundary of the structure or open boundary
constexpr bool HOMOGENIZATION = (SCENARIO==0  ||  SCENARIO==2);       // enables the homogenization method, i.e. treats all constituents as as if they were of the same species -> homogeneous assembly process in order to reduce fluctuations and stochastic effects so to come closer to the deterministic limit already with small particle numbers. To achieve the homogenization, replace the particle creation and annihilation operators by 'homogenized' versions that act on all constituent species equally and simulataneously and correspondingly rescale the activation and nucleation parameters by 1/S. For better efficiecy update only the concentration of the first species and save in the rates vectors the rates without the factors of the corresponding concentrations. The concentrations are only multiplied to calculate the total rates. This makes the activation_rates and nucleation_rates vectors constant and only requires updating of the assembly_rates and wrong_assembly_rates vectors. For better efficiency introduce additionally the homogeneous_total_rates vector analogous to total_rates which represents the sum (without the concentration factors) of the rates vectors (to calculate total_rates, homogeneous_total_rates only needs to be multiplied by the concentration factors (A*(A-1) for nucleation rate and A for all other rates (except detachment rate and decay rate which do not depend on the concentration of monomers and are updated directly in 'total_rates')).
    // It is recommended to use HOMOGENIZATION both for the activation and reversible binding scenario. In the activation scenario it is useful to avoid stochastic effects while in the reversible binding scenario it allows to detect kinetic traps more efficiently and to break up the simulation if one occurs (see break up conditions in Simulate())

constexpr short STEP_ComplexStatistics = -1;   // defines the step/interval in activation events for the complex statistics; if set to -1 it is chosen automatically as n_bursts*N*number_species/100 such that 100 statistics of the complexes are performed over the whole simulation (and saved in the data file)
constexpr bool BURSTS_ADVANCED = false;        // set BURSTS_ADVANCED to true if you want to provide particles in the activation scenario in bursts
constexpr bool CONSTANT_DELIVERY = true;       // if enabled set constant total activation rate of alpha*N per species (as long as there is at least one inactive particle) corresponding to a constant influx of active particles. Otherwise (if SCENARIO=2 and START_INACTIVE=true) simulate a constant activation rate per particle corresponding to an exponentially decaying influx.
constexpr short DETACHMENT = (SCENARIO==0);     // enables detachment processes: detachment rate delta_1 is chosen as detachment_parameter_. Alternatively, interpret detachment_parameter_ as the binding energy E_B. Choose this alternative setting in the definition of 'detachment_rates' in the constructor.
constexpr bool ADVANCED_TIME_MEASUREMENT = true;     // set this to true! measure T50 and T90, the time points where 50% and 90% yield have been reached for the first time; T50 and T90 = -1 if more than 50% of all simulations to a parameterset do not reach a yield bigger than 50 or 90% resp.
constexpr bool BREAK = true;      // if BREAK is enabled break up the siumlation prematurely if the yield in the first three runs is 0 (or smaller than any other threshold to be specified below) or when yield is larger or equal UPPER_BRAK (see below). This can help to speed up the parameter search algorithms and parameter sweeps without wasting time calculating 0 yield parameter combinations or parameters where the yield much beyond the desired outcome.
constexpr float UPPER_BREAK = 1.0;      // terminate the simulation as soon as a yield larger than UPPER_BREAK is achieved. For the reversible binding scenario, the simulation terminates automatically as soon as the yield surpasses 0.9.
long long maximum_number_steps = 1000000000;          // only relevant if DETACHMENT==true, maximum number of steps; break up the simulation if more steps are needed in a run in order to avoid getting stuck in a kinetic trap.
// constexpr bool KINETC_TRAP_CUTOFF = true;    // break up if a realization has needed more than twice as many steps as in the previous run (value stored in 'previous_steps') and has already achieved a substantial yield close to the desired yield. It is then likely that the system got trapped in a kinetic trap. This is important for the reversible binding scenario as the system can easily get stuck with a yield close to 90% and then the subsequent simulations can not continue.
Float T_max = 1e7;    // maximal simulation time. Useful to find the minimal assembly time if detachment=true in order to avoid dynamic kinetic traps (traps in which a single particle permanently binds and unbinds and a final state is not found -> in this case the time increases very quickly and the breakup can be set for instance 5 times larger than the expected minimal assembly time)
constexpr bool CONSTANT_POLYMERIZATION_RATE = false;   // If set to true all particles have a constant attachment rate nu independent of the number of neighbors they have when they bind to a complex
constexpr bool HETEROGENEOUS_RATES = false;   // if set to true, the binding rates are different for the different species as specified in the vector 'reaction_parameters' (vs. 'attachment_parameter').
constexpr bool SUPPRESS_IMMEDIATE_OUTPUT = false;  // if set to true output about the number of steps, yield and time after each run is suppressed.
//--------------------- control elements for JIS ----------------------------- //
constexpr bool JIS_MULTI_DIM = (SCENARIO==3);   // enables the creation of an 2D JIS supply protocol and the delivery of the species in bursts according to the protocol.
constexpr bool TIME_COORDINATION = JIS_MULTI_DIM && true;   // do not change this setting! If enabled interprete Delta_T as the (normalized, i.e. in units of (Cv)^-1) time interval between successive bursts, otherwise Delta_T denotes the overlap between successive bursts.
constexpr short SUPPLY_PROTOCOL = 2;      // do not change this setting! supply protocol that is used for JIS supply (only if JIS_MULTI_DIM==true)           1: snake protocol, 2: onion protocol, 3: back bone protocol (different Jis protocols of varying efficiency)
constexpr bool JIS_NON_STOICHIOMETRIC_CONCENTRATIONS = true;    // use efficient non-stoichiometric concentrations that are calculated automatically, otherwise use stoichiometric concentrations for the particles provided in the batches
constexpr Float STD_DEV_N = 0.0;       // usual value 0.001    // standard deviation of the particle number in a batch (relative to N)
constexpr bool JIS_START_AS_COMPLEX = false;   // do not change this setting! If true add the first burst in the JIS scenario as complexes rather than as monomers in order to circumvent the dimerization reaction in the first assembly step and attach all subsequent monomers with rate nu (important for combination of JIS with Dim since otherwise a low mu would also inhibit the initiation of a nucleus in the first step).
constexpr bool PRINT_JIS_PROTOCOL = JIS_MULTI_DIM && false;  // if enabled prints the JIS protocol and JIS deficiency diagram indicating which species have been delivered in unsufficient concentrations

constexpr bool TRACK_ATTACHABLES = DETACHMENT || (JIS_MULTI_DIM && !CONSTANT_POLYMERIZATION_RATE);     // do not change this setting! use TRACK_ATTACHABLES always if DETACHMENT is enabled and recommended also for JIS_MULTI_DIM  for large N if CONSTANT_POLYMERIZATION_RATE==false to improve efficiency. Each complex then keeps track of the positions it is referenced in the binding_possibilities of its respective attachable constituents. This spares to range through all elements in Vec_Del_Element() in assembly() if a species has attached and the corresponding complex must hence be deleted from binding_possibilities. Formerly, Vec_Del_Element() called from assembly() has indeed used most resources for JIS_MULTI_DIM and large N as shown by the profiler.

///////////////////////////////////////////////////////////////////////////////////////////////////////////

// global functions and parameters that define adjacency relations in the structure (needed for class 'system' as well as 'complex')

short Len;      // L (just to make it distinguishable from L in the class system)
short L_;     // L-1
short LL;     // L*L
short LL_;    // L*(L-1)
short LLL;     // L*L*L
short LLL_;    // L*L*(L-1)

short up(short n) {
    if(PERIODIC_BOUNDARY)
        return n%Len==0 ? n+L_ : n-1;
    else
        return n%Len==0 ? -1 : n-1;
}
short down(short n) {
    if(PERIODIC_BOUNDARY)
        return n%Len==L_ ? n-L_ : n+1;
    else
        return n%Len==L_ ? -1 : n+1;
}
short right(short n) {
    if(DIMENSION==1)
        return -1;
    short m = DIMENSION==2  ?  n : n%LL;
    if(PERIODIC_BOUNDARY)
        return m>=LL_ ? n-LL_ : n+Len;
    else
        return m>=LL_ ? -1 : n+Len;
}
short left(short n) {
    if(DIMENSION==1)
        return -1;
    short m = DIMENSION==2  ?  n : n%LL;
    if(PERIODIC_BOUNDARY)
        return m<Len ? n+LL_ : n-Len;
    else
        return m<Len ? -1 : n-Len;
}
short front(short n)  {
    if(DIMENSION<3)
        return -1;
    if(PERIODIC_BOUNDARY)
        return n>=LLL_ ? n-LLL_ : n+LL;
    else
        return n>=LLL_ ? -1 : n+LL;
}
short back(short n)  {
    if(DIMENSION<3)
        return -1;
    if(PERIODIC_BOUNDARY)
        return n<LL ? n+LLL_ : n-LL;
    else
        return n<LL ? -1 : n-LL;
}
short get_maximum_num_neighbors(short n)  {         // only relevant for DETACHMENT; needed to calculate detachment_stabilization in the constructor
    array<short,6> neighbors = {up(n),down(n),right(n),left(n),front(n),back(n)};
    short sum = 0;
    for(short m : neighbors)
        if(m!=-1)
            ++sum;
    return sum;
}

struct complex {
    short size;
    array<Dfloat,2*DIMENSION+1>* detachment_parameters;     // only relevant if DETACHMENT==true
    short type;       // type and ind only relevant if DETACHMENT==true. Save the type and index where they are saved in 'detachment_complexes' to enable crossreference
    int ind;
    vector<bool> data;
    vector<vector<short>> attachables;     // only relevant if TRACK_ATTACHABLES==ture. Then saves the positions it is referenced in the binding_possibilities of its respective attachable constituents
    Gillespie_groups_constant_rates<Dfloat> detachables;        // only relevant if DETACHMENT==true; lists all components that can detach
    vector<short> num_neighbors;      // only relevant if DETACHMENT==true; lists the number of neighbors for each component in the complex in order to easily determine whether or not a component is detachable
//    complex(short number_species, array<Dfloat,2*DIMENSION+1>* detachment_parameters_) : data(number_species,0),detachment_parameters(detachment_parameters_) {         // trivial constructor; only used to create the empty_entry for Const_Pos
 //       size = 0;
 //   }
    
    complex()  {     // trivial constructor; only used to create the empty_entry for Const_Pos
        size=0;
    }
    complex(short number_species, array<Dfloat,2*DIMENSION+1>* detachment_parameters_) : data(number_species,0),detachment_parameters(detachment_parameters_)   {       // constructor that reserves the space for the data to save and administrate a complex
        size = 0;
        data.resize(number_species,0);
        if(TRACK_ATTACHABLES)
            attachables.resize(number_species);
        if(DETACHMENT)  {
            detachables.reserve(2*DIMENSION*pow(number_species,float(DIMENSION-1)/DIMENSION));     // resize to 2*d*L^(d-1)
            num_neighbors.resize(number_species,0);
        }
  //      add(n1);
  //      add(n2);
    }
    bool operator[] (short n)  {
        return data[n];
    }
    short get_num_neighbors(short n)  {
        if(DETACHMENT)        // shortcut if DETACHMENT==true :)
            return num_neighbors[n];
        array<short,6> neighbors = {up(n),down(n),right(n),left(n),front(n),back(n)};
        short sum = 0;
        for(short m : neighbors)
            if(m!=-1 && data[m])
                ++sum;
        return sum;
    }
    
    Dfloat detachment_rate(short n, short num_neighbors)  {    // calculates the detachment rate of a constituent in dependence of its species and its number of neighbors
        if(DETACHMENT==0)
            return 0;
        else if(DETACHMENT==1)
            return (*detachment_parameters)[num_neighbors];
    }
    void add(short n) {    // add a new component to the complex; return the difference in the total number of detachables
        data[n] = 1;
        ++size;
        if(DETACHMENT)  {
   //         Dfloat num_detachables_prev = detachables.get_total_rate();
            array<short,6> neighbors = {up(n),down(n),right(n),left(n),front(n),back(n)};
            // update neighbors
            for(short m : neighbors)
                if(m!=-1)  {
                    ++num_neighbors[m];
                    if(data[m])   {     // remove the neighbor from 'detachables' rate_decrement times.
                        Dfloat old_rate = detachment_rate(m, num_neighbors[m]-1);
                        Dfloat new_rate = detachment_rate(m, num_neighbors[m]);
                        detachables.change_rate(m,old_rate,new_rate);
                    }
                }
            // update added constituent itself
            detachables.add_event(n, detachment_rate(n, num_neighbors[n]));
        }
    }
    
    void remove(short n) {
        data[n] = 0;
        --size;
   
        detachables.remove_event(n, detachment_rate(n, num_neighbors[n]));
  
        array<short,6> neighbors = {up(n),down(n),right(n),left(n),front(n),back(n)};
        for(short m : neighbors)
            if(m!=-1)  {
                --num_neighbors[m];
                if(data[m])   {
                    detachables.change_rate(m, detachment_rate(m, num_neighbors[m]+1), detachment_rate(m, num_neighbors[m]));
                }
            }
    }
};

class System {
    RandonNumberGenerator& rng;
    const short L;
    const short number_species;
    const short N;
    short n_bursts;
    const short critical_size;
    
    vector<Float> activation_parameters;
    Float nucleation_parameter;
    Float reaction_parameter;
    vector<Float> reaction_parameters;       // only relevant if HETEROGENEOUS_RATES==true; saves the heterogeneous reaction rates
    Float wrong_reaction_parameter;
    Float decay_parameter;
    array<Dfloat,2*DIMENSION+1> detachment_parameters = {0}; // only relevant if DETACHMENT==true; mapping of the number of neighbors to the corresponding (integer) detachment rate. First entry is for 0 neighbors, second entry for 1 neighbor, third for 2 neighbors and so on. Not specified rates at the end are set as 0.
    function<void(int,short,int)> detachment_crossreference = [&](int event, short type, int ind){complexes[event].type=type; complexes[event].ind=ind; };   // define detachment_crossreference as function object that is passed to detachment_complexes alias Gillespie_groups_similar_rates and thereby automatically updates the crossreference ind and type in complex.
    Float Delta_T;
    
    vector<short> inactive_particles;
    vector<short> active_particles;
    ConstPos<complex> complexes;
    vector<short> subcritical_complexes;
    vector<Float> activation_rates;
    vector<Float> nucleation_rates;
    vector<Float> assembly_rates;
    vector<vector<short>> assembly_possibilities;
    vector<Float> wrong_assembly_rates;
    vector<vector<short>> wrong_assembly_possibilities;
    Gillespie_groups_similar_rates<Dfloat,function<void(int,short,int)>> detachment_complexes;   // only relevant if DETACHMENT==true; Gillespie container that contains the indices and rates of the detachable complexes, i.e. the indices of all existing complexes
//    Dfloat max_detachment_rate;       // only relevant if DETACHMENT==true; maximum detachment rate of a single complex in order to be able to use the rejection method
//    long long total_num_detachables;     // only relevant if DETACHMENT==true; total number of detachable constituents in all complexes in order to be able to calculate the total detachment rate
    array<Float,6> total_rates;   // 0: total_activation_rate; 1: total_nucleation_rate; 2: total_assembly_rate; 3: total_decay_rate; 4: total_wrong_assembly_rates; 5: total detachment rate
    array<Float,5> homogeneous_total_rates;      // only relevant if HOMOGENIZATION=true. Same structure as in total_rates (without the detachment rate) but saves all rates without the corresponding factors of A. Therefore, they are the sums of the respective rates vectors if HOMOGENIZATION while the real total rates in total_rates do bear the factors of A. This serves to increase the efficiency for HOMOGENIZATION
    short N_tot;
    short complete_structures;
    vector<short> number_defects;
    vector<vector<short>> JIS_protocol;        // vector of sets of species that are supplied simultaneously in JIS bursts
    vector<short> JIS_protocol_numbers;
    vector<short> C;          // matrix of supply protocol indices. Build in make_JIS_protocol() and needed for print_dimerization_seeds()
    
public:
    void set_reaction_parameters(vector<Float>& reaction_parameters_)  {
        reaction_parameters = reaction_parameters_;
    }
private:
    void make_reaction_parameters_fixed_mean(int size, Float stddev, Float min_reaction_parameter, RandonNumberGenerator& rng)  {      // creates the reaction_parameters vector of size 'size' of random reaction paramters with standarddeviation 'stddev' and an exactly fixed mean
        reaction_parameters.resize(size);
        for(short i=0; i<size; ++i)  {
            reaction_parameters[i] = 1 + rng.GaussRand()*stddev;
            if(reaction_parameters[i]<min_reaction_parameter)
                reaction_parameters[i]=min_reaction_parameter;
        }
        // shift all values uniformly to obtain a constant mean.
        Float correction = (accumulate(reaction_parameters.begin(), reaction_parameters.end(), Float(0.0))-size)/size;
        for(short i=0; i<size; ++i)  {
            reaction_parameters[i] -= correction;
        }
        // print reaction_parameters vector
  //      cout << "reaction_parameters = [";
  //      for(short i=0; i<reaction_parameters.size()-1; ++i)
  //          cout << reaction_parameters[i] << ", ";
  //      cout << reaction_parameters.back() << "];" << endl;
    }
    
    short active_particles_neighbor(short n, short s)  {
        short m;
        switch (s) {
            case 1:
                m = down(n);
                break;
            case -1:
                m = up(n);
                break;
            case 2:
                m = right(n);
                break;
            case -2:
                m = left(n);
                break;
            case 3:
                m = front(n);
                break;
            case -3:
                m = back(n);
                break;
        }
        if(HOMOGENIZATION)
            return m==-1 ? 0 : active_particles[0];
        else
            return m==-1 ? 0 : active_particles[m];
    }
    short inactive_particles_neighbor(short n, short s)  {
        short m;
        switch (s) {
            case 1:
                m = down(n);
                break;
            case -1:
                m = up(n);
                break;
            case 2:
                m = right(n);
                break;
            case -2:
                m = left(n);
                break;
            case 3:
                m = front(n);
                break;
            case -3:
                m = back(n);
                break;
        }
        if(HOMOGENIZATION)
            return m==-1 ? 0 : inactive_particles[0];
        else
            return m==-1 ? 0 : inactive_particles[m];
    }
    

////// make JIS supply protocol ////////
    bool is_attachable(vector<short>& C, short n, short num_neighbors=-1)  {     // attachable only if the particle has a specified number of neighbors; num_neighbors=-1 indicates that the number of neighobrs is irrelevant
        if(C[n]!=0)
            return false;
        short sum=0;
            for(short m : {up(n),down(n),right(n),left(n),front(n),back(n)})
                if(m!=-1 && C[m]>0) {
                    if(num_neighbors==-1)      // if number of neighbors is arbitrary
                        return true;
                    else
                        ++sum;
                }
        return sum==num_neighbors;
    }
    void protocol_add(vector<short>& C, short n, short k)  {
        C[n]=k;
        for(short m : {up(n),down(n),right(n),left(n),front(n),back(n)})
            if(m!=-1 && C[m]==0)
                C[m]=-1;
        JIS_protocol[k-1].push_back(n);
    }
    void next_protocol_step(vector<short>& C)  {
        for(short i=0; i<number_species; ++i)
            if(C[i]==-1)
                C[i]=0;
    }
    short get_dimerization_potential(vector<short>& C, short n)  {   // find the number of neighbors with a protocol number larger by 1 so that thes are possible dimerization partners.
 //       if(C[n]==1)     // the dimerizatin potential of the first protocol species is 0 because dimerization with this this species is desired.
 //           return 0;
        short dimerization_potential = 0;
        for(short m : {up(n),down(n),right(n),left(n),front(n),back(n)})
            if(m!=-1 && C[m]==C[n]+1)    // add the neighboring species if it has a protocol number larger by 1
                ++dimerization_potential;
        return dimerization_potential;
    }
    short get_dimer_relevance(vector<short>& C, short n)  {    // add up the dimerization potentials of all species "on the way" and of the species considered itself. Currently works best in the group of the "perfect supply protocols".
        if(C[n]==1)
            return 0;
        vector<short> dimerization_potential(number_species);
        vector<short> predecessors;
        short marker1 = 0, marker2 = 1;      // marker1 and marker2 mark the range of the last level of species that have been added as relevant dimerisers.
        for(short i=0; i<number_species; ++i)
            dimerization_potential[i] = get_dimerization_potential(C, i);
        predecessors.reserve(number_species);
        predecessors.push_back(n);
        while(marker1!=marker2)  {
            for(short i=marker1; i<marker2; ++i)   {
                n = predecessors[i];
                for(short m : {up(n),down(n),right(n),left(n),front(n),back(n)})
                if(m!=-1 && C[m]<C[n] && find(predecessors.begin()+marker2,predecessors.end(),m)==predecessors.end())    // add the species if it has a smaller protocol number and if if it has not already been added (as a neighbor of another species)
                predecessors.push_back(m);
            }
            marker1 = marker2;
            marker2 = predecessors.size();
        }
        short dimer_relevance = 0;
        for(short s : predecessors)
            dimer_relevance += dimerization_potential[s];
        return dimer_relevance;
    }
    
    
    template<class T>        // dimensionality plot in column
    void dimensionality_plot(vector<T>& C, short width)  {         // plots a linear vector that contains some information about the species like supply_protocol or supply_protocol_numbers in multidimensional slices appropriate to the actual dimensionality
        for(short k=0; k<(DIMENSION==3 ? L : 1); ++k)  {       // only for dimension 3
            for(short i=0; i<L; ++i)  {                      // for all dimensions
                for(short j=0; j<(DIMENSION>=2 ? L : 1); ++j)       // for dimension 2 and 3
                    cout << setw(width) << C[i+j*L+k*L*L];
                cout << endl;
            }
            cout << endl;
        }
        cout << endl;
    }
    
    template<class T>
    void dimensionality_plot_in_row(vector<T>& C, short width)  {         // plots a linear vector that contains some information about the species like supply_protocol or supply_protocol_numbers in multidimensional slices appropriate to the actual dimensionality
        for(short i=0; i<L; ++i)  {             // for all dimensions
            for(short k=0; k<(DIMENSION==3 ? L : 0); ++k)  {       // only for dimension 3
                for(short j=0; j<(DIMENSION>=2 ? L : 0); ++j)       // for dimension 2 and 3
                    cout << setw(width) << C[i+j*L+k*L*L];
                cout << "  ";
            }
            cout << endl;
        }
        cout << endl;
    }
    
    void make_JIS_supply_protocol()  {     // not yet adopted for 3D !!!!!!!
        JIS_protocol.clear();
        JIS_protocol.reserve(L+5);
  //      vector<short> C(number_species,0);
        C.resize(number_species,0);
        short ADDED;

// Layer protocol: make simple supply protocol following direct species order
/*        for(short i=0; i<number_species; ++i)  {
            JIS_protocol.push_back({});
            protocol_add(C, i, i+1);
        }
 */
// Snake protocol: make simple supply protocol following a connected curled line
        if(SUPPLY_PROTOCOL==1)  {
            short e=1;
            for(short i=0; i<(L+1)/2; ++i)  {
                for(short k=0, j=i*2*L; k<L; ++k, ++j, ++e)  {
                    JIS_protocol.push_back({});
                    protocol_add(C, j, e);
                }
                if(e==number_species+1)
                    break;
                for(short k=0, j=(i+1)*2*L-1; k<L; ++k, --j, ++e)  {
                    JIS_protocol.push_back({});
                    protocol_add(C, j, e);
                }
            }
        }
// back bone protocol
    else if(SUPPLY_PROTOCOL==3)    {
        JIS_protocol.resize(number_species);
        short s=0;
        short delay = 6;      // number of assembly steps that the side tracks are delyed from the back bone
        short e1=1, e2=2*L+delay, e3=2*L+1, e4=2*L+2;
        
        while(s<=number_species)   {
            for(short k=0, e=e1; k<L; ++k)     // first column
                protocol_add(C, s++, e++);
            if(s>=number_species)
                break;
            for(short k=0, e=e2; k<L; ++k) {    // second column (with irregularity at the last)
                if(k==L-1)
                    e-=delay;
                protocol_add(C, s++, e--);
            }
            if(s>=number_species)
                break;
            for(short k=0, e=e3; k<L; ++k)      // third column
                protocol_add(C, s++, e--);
            if(s>=number_species)
                break;
            for(short k=0, e=e4; k<L; ++k)  {   // fourth column (with irregularity at the first)
                protocol_add(C, s++, e++);
                if(k==0)
                    e+=delay;
            }
            e1+=2*L+2;
            e2+=2*L+2;
            e3+=2*L+2;
            e4+=2*L+2;
        }
        for(short i=JIS_protocol.size(); i>0; --i)  {       // delete the remaining zero entries in the protocol
            if(JIS_protocol[i].size()>0) {
                JIS_protocol.resize(i+1);
                break;
            }
        }
    }
// Onion Protocol: set initial nucleus as a cross consisting of 5 species in the middle
        // -> write supply protocol such that only the middle species is set initially and all the rest is done automatically. However, the first two bursts are then provided simultaneously.
    else if(SUPPLY_PROTOCOL==2)  {
        short k=1;
        JIS_protocol.push_back({});
        short n=L/2;
        short start_species = DIMENSION==1  ?  n  :  (DIMENSION==2  ?  n*(1+L)  :  n*(1+L+L*L));    // set the first species in the middle of the structure and let the algorithm determine the subsequent batches growing outwards
        protocol_add(C, start_species, k);
        ADDED = 1;
// iteratively find set of possible species that can attach to the existing structure but that cannot nucleate.
        short num_neighbors = -1;
        while(ADDED<number_species)   {
            ++k;
 //           switch(k%3)  {
 //               case 2:
 //                   num_neighbors = 2;
 //                   break;
 //               case 0:
 //                   num_neighbors = 1;
 //                   break;
 //               default:
 //                   num_neighbors = 3;
 //                   break;
 //           }
  
            JIS_protocol.push_back({});
            next_protocol_step(C);
            for(short n=0; n<number_species; ++n)
                if(is_attachable(C,n,num_neighbors)) {
                    protocol_add(C,n,k);
                    ++ADDED;
                }
         }
    }
// make JIS_protocol_numbers
        /*
        Float p = 1.0;
        Float s = 2*(1-p)/L;       // formula holds for odd L
        JIS_protocol_numbers.resize(JIS_protocol.size());
        for(short i=0; i<JIS_protocol_numbers.size(); ++i)  {
            p+=s;
            JIS_protocol_numbers[i] = p*N;
        }
         */
        
        Float p = 0.07;   // optimum: p=0.07 for 90% yield    // fraction of resources that is distributed non-stoichiometrically in linearly increasing concentration profile. Concentration of initial species and hence the maximal yield that can be acieved equals 1-p
        
    // make supply protocol by simple formula
        if(JIS_NON_STOICHIOMETRIC_CONCENTRATIONS==false)
            JIS_protocol_numbers.resize(number_species,N);
        else  {
            JIS_protocol_numbers.resize(number_species);
            for(short i=0; i<number_species; ++i)  {
                Float n = C[i];
                if(DIMENSION==1)
                    JIS_protocol_numbers[i] = n-1;
                else if(DIMENSION==2)
               //     JIS_protocol_numbers[i] = ceil(n/2*(n/2+1));
                    JIS_protocol_numbers[i] = 1./4.*pow((n+1),2);  // 1./4.*  with prefactor it works better (theoretically it should be invariant to prefactors but rounding to the integer makes the change. Important is that the third batch has 2 times more excess monomes than the second batch, which is guaranteed by the prefactor but not without it. Should therefore also work when using it without the prefactor and replacing the 9 in batch 2 by 8 in the numbers protocol.
                else if(DIMENSION==3)
                JIS_protocol_numbers[i] = pow((n+1),3);      // for some reason it works much better without the prefactor 1/8. Normally, prefactors should be invariant... (test this also in the 2D case!) must have to do smething with rounding to integer values in the cast to JIS_protocol_numbers.... better would be to save it here as Floats still and only after multiplying with N cast the protocol numbers to integers. 
                  //  JIS_protocol_numbers[i] = 1./8.*pow((n+1),3);
            }
            short n=L/2;
            short start_species = DIMENSION==1  ?  n  :  (DIMENSION==2  ?  n*(1+L)  :  n*(1+L+L*L));
            JIS_protocol_numbers[start_species] = 0;      // set number of first protocol species to 0
        }
        if(DIMENSION==2 && PERIODIC_BOUNDARY && SUPPLY_PROTOCOL==2)   {   // multiply the excess concentration of species that have additional neighbors because of periodic boundary conditions with a factor of 2.
            for(short i=0; i<number_species; ++i)
                if(i<L || i%L==0)
                    JIS_protocol_numbers[i] *= 2;
            JIS_protocol_numbers[0] *= 2;    // due to the additional concentrations, the species in the upper left corner must be multiplied by another factor of 2;
        }
        
        
        // print protocol numbers
        if(PRINT_JIS_PROTOCOL)    {
            dimensionality_plot(C, 4);
            dimensionality_plot(JIS_protocol_numbers, 6);
        }
    
        if(JIS_NON_STOICHIOMETRIC_CONCENTRATIONS)  {
            int h = accumulate(JIS_protocol_numbers.begin(), JIS_protocol_numbers.end(), 0);
            Float x = p*N*number_species/h;
            for(short i=0; i<JIS_protocol_numbers.size(); ++i)  {
                JIS_protocol_numbers[i] *= x;
                JIS_protocol_numbers[i] += (1-p)*N;     // add the remaining ressources that are equal among all species
            }
        }
        
    // add Gaussian fluctuations on the particle numbers
        if(STD_DEV_N>0)
            for(short i=0; i<JIS_protocol_numbers.size(); ++i)
                JIS_protocol_numbers[i] += STD_DEV_N * N * rng.GaussRand();
// calculate N_tot from the JIS protocols. N_tot is usually not exactly N*number_species but might slightly deviate
        N_tot = accumulate(JIS_protocol_numbers.begin(), JIS_protocol_numbers.end(), 0);
// set n_bursts as the total number of JIS bursts
        n_bursts = JIS_protocol.size();

// print C
        if(PRINT_JIS_PROTOCOL)
            dimensionality_plot(JIS_protocol_numbers, 6);
    
// print protocol
   /*
        for(short i=0; i<JIS_protocol.size(); ++i)  {
            for(short j=0; j<JIS_protocol[i].size(); ++j)
                cout << setw(4) << JIS_protocol[i][j];
            cout << endl;
        }
        cout << endl;
  */
// print JIS_protocol_numbers
 //       for(short i : JIS_protocol_numbers)
 //           cout << i << "  ";
 //       cout << endl << endl;
 
    /*
        if(PRINT_JIS_PROTOCOL)  {
            for(short i=0; i<L; ++i)  {
                for(short j=0; j<L; ++j)
                    cout << setw(6) << JIS_protocol_numbers[i+j*L];
                cout << endl;
            }
            cout << endl;
        }
     */
    }
 /////////////////////////////////////////////////////////////////////////////
    
    short get_ring_size(short complex_index) {
        return complexes[complex_index].size;
    }
    
    void recalculate_activation_rate(short n) {
        total_rates[0] -= activation_rates[n];
        if(CONSTANT_DELIVERY)
            activation_rates[n] = inactive_particles[n]>0  ?  N*activation_parameters[n] : 0;
        else
            activation_rates[n] = inactive_particles[n]*activation_parameters[n];
        total_rates[0] += activation_rates[n];
    }
    void recalculate_nucleation_rate(short n) {
        total_rates[1] -= nucleation_rates[n];
        if(DIMENSION==1)
            nucleation_rates[n] = nucleation_parameter * active_particles[n] * active_particles_neighbor(n,1);
        else if(DIMENSION==2)
            nucleation_rates[n] = nucleation_parameter * active_particles[n] * (active_particles_neighbor(n,1)+active_particles_neighbor(n,2));
        else if(DIMENSION==3)
            nucleation_rates[n] = nucleation_parameter * active_particles[n] * (active_particles_neighbor(n,1)+active_particles_neighbor(n,2)+active_particles_neighbor(n,3));
        total_rates[1] += nucleation_rates[n];
    }
    void recalculate_assembly_rate(short n) {
        total_rates[2] -= assembly_rates[n];
        if(HETEROGENEOUS_RATES)
            assembly_rates[n] = reaction_parameters[n] * active_particles[n] * assembly_possibilities[n].size();
        else
            assembly_rates[n] = reaction_parameter * active_particles[n] * assembly_possibilities[n].size();
        total_rates[2] += assembly_rates[n];
    }
    void recalculate_decay_rate()  {
        total_rates[3] = subcritical_complexes.size()*decay_parameter;
    }
    void recalculate_wrong_assembly_rate(short n) {
        if(WRONG_BINDING==false)
            return;
        total_rates[4] -= wrong_assembly_rates[n];
        wrong_assembly_rates[n] = wrong_reaction_parameter * active_particles[n] * wrong_assembly_possibilities[n].size();
        total_rates[4] += wrong_assembly_rates[n];
    }
    void recalculate_detachment_rate()   {     // only relevant if DETACHMENT==true; updates the total detachment rate.   Previous version: updates max_num_detachables, total_num_detachables and total_rates[5]. increment is the increment to total_num_detachables; provide the number of detachables of the modified complex to check and in case update max_num_detachables
        total_rates[5] = detachment_complexes.get_total_rate();
   }
    void recalculate_total_rates()  {       // recalculate the total rates that are otherwise only incremented; so that numerical errors do not heap up and mess up the tests on the total_rates after a while.
        if(HOMOGENIZATION)  {
            recalculate_homogeneous_total_rates();
            return;
        }
        total_rates[0] = accumulate(activation_rates.begin(),activation_rates.end(),0.0);
        total_rates[1] = accumulate(nucleation_rates.begin(),nucleation_rates.end(),0.0);
        total_rates[2] = accumulate(assembly_rates.begin(),assembly_rates.end(),0.0);
        if(WRONG_BINDING)
            total_rates[4] = accumulate(wrong_assembly_rates.begin(),wrong_assembly_rates.end(),0.0);
        if(DETACHMENT)
            detachment_complexes.recalculate_total_rates();
    }
    
public:
    System(short L__, short N_, short n_bursts_, short critical_size_, Float activation_parameter_, Float nucleation_parameter_, Float reaction_parameter_, Float wrong_reaction_parameter_, Float decay_parameter_, Float detachment_parameter_, Float Delta_T, float parameter, RandonNumberGenerator& rng_) : rng(rng_), L(L__), number_species(DIMENSION==1 ? L : (DIMENSION==2 ? L*L : L*L*L)), N(N_), n_bursts(n_bursts_),critical_size(critical_size_),complexes(complex(),10*N),Delta_T(Delta_T)  // provide n_bursts times N inactive particles that are activated with rate activation_parameter...  // provide regulation strangth Q in dimensionless units but transform this into the dimensionful regulation strength q for the simulation.
    
    {
    //    previous_steps_breakup = 2000000;
    //    previous_steps_breakup = INT_MAX;
        // set the global parameters
               // be careful to initialize only in one thread when using parallelization
#ifndef PARALLELIZE
            Len = L;
            L_ = L-1;
            LL = L*L;
            LL_ = L*(L-1);
            LLL = L*L*L;
            LLL_ = L*L*(L-1);
#endif
        if(HOMOGENIZATION && (JIS_MULTI_DIM || BURSTS_ADVANCED)) {           //check consitency of settings
            cout << "Homogenization and other settings incompatible" << endl;
            abort();
        }
        if(BURSTS_ADVANCED && JIS_MULTI_DIM)  {
            cout << "BURST_ADVANCED and JIS_MULTI_DIM incompatible" << endl;
            abort();
        }
        // if L and number_species are not constexpr assign here the values for L and number_species and resize all vectors to number_species
        activation_parameters.resize(number_species);
        active_particles.resize(number_species);
        inactive_particles.resize(number_species);
        activation_rates.resize(number_species);
        nucleation_rates.resize(number_species);
        assembly_rates.resize(number_species);
        wrong_assembly_rates.resize(number_species);
        assembly_possibilities.resize(number_species);
        wrong_assembly_possibilities.resize(number_species);
        
        fill(activation_parameters.begin(),activation_parameters.end(),activation_parameter_);
 //       for(short i=0; i<activation_parameters.size()/2; ++i)  {     // make inhomogeneous activation parameters
 //           activation_parameters[i] *= pow(parameter,(i+1));
 //           activation_parameters[number_species-i-1] *= pow(parameter,(i+1));
         //   activation_parameters[i] += i*parameter;
         //   activation_parameters[number_species-i-1] += i*parameter;
 //       }
//        for(short i=0; i<number_species; ++i)
//            cout << activation_parameters[i] << ",  ";
//        cout << endl;
        
        nucleation_parameter = nucleation_parameter_;
        reaction_parameter = reaction_parameter_;
        wrong_reaction_parameter = wrong_reaction_parameter_;
        decay_parameter = decay_parameter_;
 //       detachment_parameter = detachment_parameter_;
        if(HOMOGENIZATION)   {      // if Homogenization is enabled, rescale activation and nucleation by 1/S
            fill(activation_parameters.begin(),activation_parameters.end(),activation_parameter_/number_species);
            nucleation_parameter /= number_species;      // per nucleation event destroy only one set of active particles to avoid negative concentrations
 //           reaction_parameter /= number_species;
 //           wrong_reaction_parameter /= number_species;
 //           decay_parameter /= number_species;
        }
        
        for(short i=0; i<number_species; ++i)  {        // reserve space for vectors
            assembly_possibilities[i].reserve(100);
            assembly_possibilities[i].reserve(100);
            if(WRONG_BINDING)  {
                wrong_assembly_possibilities[i].reserve(100);
                wrong_assembly_possibilities[i].reserve(100);
            }
        }
        if(WRONG_BINDING)
            number_defects.reserve(100);
        subcritical_complexes.reserve(10);
// set N_tot and make JIS_supply protocol if JIS_MULTI_DIM
        if(HOMOGENIZATION)
            N_tot = N;
        else if(BURSTS_ADVANCED==false && JIS_MULTI_DIM==false) // if BURSTS_ADVANCED==true (indication to use advanced bursts that may have no predefined size) remain with N_tot = 0 (N_tot is then updated by the function bursts_advanced after each burst) otherwise set N_tot = N*number_species*n_bursts; for JIS_MULTI_DIM set N_tot accordingly in make_JIS_protocol
            N_tot = N*number_species*n_bursts;
        else if(JIS_MULTI_DIM)
            make_JIS_supply_protocol();
        
        if(DETACHMENT)  {
    // variation of detachment rate
            detachment_parameters[0] = detachment_parameter_;
            detachment_parameters[1] = detachment_parameter_;
            detachment_parameters[2] = 0;
            detachment_parameters[3] = 0;
    // variation of binding energy (interpret detachment_parameter as binding energy)
     //       Float A = 1e18*N;  //  1e18*N;
     //       detachment_parameters[0] = A*exp(-detachment_parameter_);
     //       detachment_parameters[1] = A*exp(-detachment_parameter_);
     //       detachment_parameters[2] = A*exp(-2*detachment_parameter_);
     //       detachment_parameters[3] = A*exp(-3*detachment_parameter_);
        
            vector<Float> rate_discrimination;    // group rates in distinction by the (nonzero) detachment_parameters.
            if(detachment_parameters.back() > 0)
                rate_discrimination.push_back(detachment_parameters.back());
            for(short i=detachment_parameters.size()-2; i>=0; --i)   // go from back to beginning of detachment_parameters and add to rate_discrimination if the parameter is larger than 0 and bigger than the previous parameter at least by a factor of 2.
                if(detachment_parameters[i]>0 && detachment_parameters[i]/detachment_parameters[i+1]>2.)
                    rate_discrimination.push_back(detachment_parameters[i]);
            reverse(rate_discrimination.begin(),rate_discrimination.end());
            detachment_complexes.set_grouping(rate_discrimination, Float(L)/2*N);
        }
    }
    
private:
    void initialize()    {
        if(BURSTS_ADVANCED)     // if BURSTS_ADVANCED==true set N_tot = 0 (N_tot is then updated by the function bursts_advanced after each burst)
            N_tot = 0;
        complete_structures = 0;
        number_defects.clear();             // clear vectors
        for(short i=0; i<number_species; ++i)  {
            assembly_possibilities[i].clear();
            wrong_assembly_possibilities[i].clear();
        }
        complexes.clear();
        subcritical_complexes.clear();
        if(DETACHMENT)
            detachment_complexes.clear();
        fill(active_particles.begin(),active_particles.end(),0);
        fill(inactive_particles.begin(),inactive_particles.end(),0);
        if(HETEROGENEOUS_RATES)
            make_reaction_parameters_fixed_mean(number_species, 0.5, 0.2, rng);
        if(HOMOGENIZATION)  {
            // initialize homogeneous rate vectors
            fill(activation_rates.begin(),activation_rates.end(),activation_parameters[0] * (CONSTANT_DELIVERY ? N : 1));  // activation rates remain fixed throughout the simulation; only total rate is modified
            fill(nucleation_rates.begin(),nucleation_rates.end(),nucleation_parameter*DIMENSION);       // nucleation rates remain fixed throughout the simulation; only total rate is modified
            if(PERIODIC_BOUNDARY==false)  {            // if there are no periodic boundary conditions correct the nucleation rates at the right and lower boundary and correspondingly the total rate
                for(short i=(L-1); i<number_species; i+=L)     // correct for boundary in down direction (for 1D,2D and 3D)
                    nucleation_rates[i] -= nucleation_parameter;
                if(DIMENSION>=2)
                    for(short j=L*(L-1); j<number_species; j+=L*L)  // correct for boundary in right direction (only 2D and 3D)
                        for(short i=j; i<j+L; ++i)
                            nucleation_rates[i] -= nucleation_parameter;
                if(DIMENSION>=3)
                    for(short i=L*L*(L-1); i<number_species; ++i)       // correct for boundary in front direction (only 3D)
                        nucleation_rates[i] -= nucleation_parameter;
            }
            fill(assembly_rates.begin(),assembly_rates.end(),0.);     // assembly and wrong_assembly_rates get modified according to the binding possibilities due to the existing complexes
            fill(wrong_assembly_rates.begin(),wrong_assembly_rates.end(),0.);
                // initialize homogeneous_total_rates
            homogeneous_total_rates[0] = activation_rates[0]*number_species;
            homogeneous_total_rates[1] = nucleation_rates[0]*number_species - (PERIODIC_BOUNDARY ? 0 : nucleation_parameter*DIMENSION*pow(L,DIMENSION-1));
            fill(homogeneous_total_rates.begin()+2,homogeneous_total_rates.end(),0.);
        }
        else  {
            fill(activation_rates.begin(),activation_rates.end(),0.);
            fill(nucleation_rates.begin(),nucleation_rates.end(),0.);
            fill(assembly_rates.begin(),assembly_rates.end(),0.);
            fill(wrong_assembly_rates.begin(),wrong_assembly_rates.end(),0.);
        }
        total_rates.fill(0.);
        
        burst(0);    // initializes inactive particles, activation nucleation and assembly rates and recalculates total_rates; if BURSTS_ADVANCED==true uses automatically burst_advanced()
    }
    
    void burst(short n)  {
        if(BURSTS_ADVANCED) {       // if BURSTS_ADVANCED or JIS_MULTI_DIM is activated call burst_advanced() instead
            burst_advanced(n);
            return;
        }
        else if(JIS_MULTI_DIM)  {
            JIS_MULTI_DIM_burst(n);
            return;
        }
        if(HOMOGENIZATION)  {
            homogeneous_burst();
            return;
        }
        if(START_INACTIVE==true)  {
            fill(inactive_particles.begin(),inactive_particles.end(),N);
            for(short i=0; i<number_species; ++i)
                recalculate_activation_rate(i);
        }
        else  {
            fill(active_particles.begin(),active_particles.end(),N);
            for(short i=0; i<number_species; ++i)  {
                recalculate_nucleation_rate(i);
                recalculate_assembly_rate(i);
                recalculate_wrong_assembly_rate(i);
            }
        }
        recalculate_total_rates();
    }
    
    void burst_advanced(short n) {         // TODO: check this again if it should be used
        fill(active_particles.begin(),active_particles.end(),0);
        fill(nucleation_rates.begin(),nucleation_rates.end(),0.);
        static short counter = 0;           // static variable counter counts the number of times a burst is created. Use this variable if the different bursts should have different sizes or statistics (see comments below).
  //      poisson_distribution<short> distribution(1000);      // <- adopt this line if you want the number of particles be drawn from some distribution; e.g. poisson_distribution<short> distribution(4.0); uses a poisson distribution with mean 4.0. This and other cool distributions are part of <random>.
  //      normal_distribution<double> distribution(1000,20);     // alternatively, use a Gauss distribution (first argument=mean, second argument=std dev.)
        vector<short> burst_sizes = {100,200};        // <- create a vector with the respective sizes of the subsequent bursts. The size of the vector must match the number of bursts n_bursts!! use counter to access the corresponding elements below; you could also use the vector to define different parameters for an arbitrary distribution but then you must define a new distribution object for each burst in the loop below.
        for(short i=0;i<number_species; ++i) {
 //           inactive_particles[i] = (int)distribution(mt);       // <- adopt this line
            inactive_particles[i] = burst_sizes[counter];  // <- use this line instead of the one above if all species have the same copy number but burst sizes are different for all bursts and given by the vector burst_sizes.
            recalculate_activation_rate(i);
        }
        recalculate_total_rates();
        N_tot += accumulate(inactive_particles.begin(), inactive_particles.end(), 0.);
        counter = ++counter % n_bursts;         // counter counts from 0 to n_bursts-1
    }
    
    void JIS_add_monomer_as_complex(short n)  {   // adds a monomer as a complex in order to circumvent the dimerization reaction in the first assembly step of the JIS scenario and attach all subsequent monomers with rate nu (important for combination of JIS with Dim since otherwise a low mu would also inhibit the iniitiation of a nucleus in the first step)
        short complex_index = complexes.add();
        complex& comp = complexes[complex_index];
        if(comp.data.size()==0)    // if comp is still empty reserve and resize the space (and set the pointer to detachment_parameters)
            comp = complex(number_species,&detachment_parameters);
        comp.add(n);     // add the two constituents to the complex
        update_assembly_possibilities(complex_index, n);
        if(DETACHMENT)  {
            Dfloat detach_rate = comp.detachables.get_total_rate();
        //          recalculate_detachment_rate(detach_rate,detach_rate);
            detachment_complexes.add_event(complex_index, detach_rate, detachment_crossreference);
            recalculate_detachment_rate();
        }
    }
    
    void JIS_MULTI_DIM_burst(short JIS_counter)  {
        /*
        Float p = 0.1*N/number_species * JIS_protocol[JIS_counter].size();    // a priori removal of complexes: corrects for dimerization of current burst
 //       Float p = (JIS_counter==0)  ?  0 : 0.1*N/number_species * JIS_protocol[JIS_counter-1].size();        // a posteriori removal of complexes: corrects for dimerization of previous burst
        short n = UnifRand()<=(p-(short)p) ? (p+1) : p;
        if(complexes.content()>=n)        // remove n complexes at the beginning of each burst if possible
            for(short i=0; i<n; ++i)
                remove_complex();
        */
    //    short num = JIS_protocol_numbers[JIS_counter];
        if(JIS_START_AS_COMPLEX && JIS_counter==0)  {   // if JIS_START_AS_COMPLEX add the first burst as complexes rather than as monomers in order to circumvent the dimerization reaction in the first assembly step of the JIS scenario and attach all subsequent monomers with rate nu (important for combination of JIS with Dim since otherwise a low mu would also inhibit the iniitiation of a nucleus in the first step).
            short species = JIS_protocol[0][0];
            for(short i=0; i<JIS_protocol_numbers[species]; ++i)
                JIS_add_monomer_as_complex(species);
            return;
        }
        if(START_INACTIVE==false)
            for(short i : JIS_protocol[JIS_counter])  {
                active_particles[i] = JIS_protocol_numbers[i];
                recalculate_assembly_rate(i);
                recalculate_wrong_assembly_rate(i);
            }
        else    // if START_INACTIVE==true
            for(short i : JIS_protocol[JIS_counter])  {
                inactive_particles[i] = JIS_protocol_numbers[i];
                recalculate_activation_rate(i);
            }
        /*
        if(JIS_counter==0 && SUPPLY_PROTOCOL==2)  {            // correct for the first species of the first burst which is provided in smaller number compared to the other species in the first burst
            short i=JIS_protocol[0][0];
            active_particles[i] -= JIS_protocol_numbers[1]-JIS_protocol_numbers[0];     // the right hand side is identical to s in make_JIS_protocol().
            recalculate_assembly_rate(i);
            recalculate_wrong_assembly_rate(i);
        }
         */
        for(short i=0; i<number_species; ++i)    // nucleation rate must be calculated for all species. Assembly rates and wrong assembly rates only need to be calculated for the bursted particles.
            recalculate_nucleation_rate(i);
        recalculate_total_rates();
    }
    /*
    bool new_JIS_burst_minimum(short JIS_counter)  {   // check condition for new JIS burst:  check if all active particle concentrations of the previous JIS burst have dropped below 1/q and so the next burst is triggered
        bool new_burst = true;
        for(short i : JIS_protocol[JIS_counter])  {
            if(START_INACTIVE==false && active_particles[i]>1/Delta_T)
                new_burst = false;
            else if(START_INACTIVE && inactive_particles[i]>1/Delta_T)
                new_burst = false;
        }
        return new_burst;
    }
     */
    bool new_JIS_burst_average(short JIS_counter)  {    // check condition for new JIS burst:  check if the average of all active particle concentrations of the previous JIS burst has dropped below 1/q and so the next burst must be triggered
        if(JIS_counter==0 && SUPPLY_PROTOCOL==2)   // in case of the onion protocol fire the second burst (four species around the middle species) immediately after the zeroth (single species in the middle)
            return true;
        if(JIS_counter==JIS_protocol.size()-1)    // if it is the last JIS burst then do not throw a new burst (do not stop the while loop prematurely in Simulate)
            return false;
        Float average = 0.;
        for(short i : JIS_protocol[JIS_counter]) {
            if(START_INACTIVE)
                average += inactive_particles[i];
            else
                average += active_particles[i];
        }
        average /= JIS_protocol[JIS_counter].size();
        return average < 1/Delta_T ? true : false;
    }
    
    bool new_JIS_burst_time(short JIS_counter, double t)  {    // check condition for new JIS burst:  check if the average of all active particle concentrations of the previous JIS burst has dropped below 1/q and so the next burst must be triggered
        if(JIS_counter==0 && SUPPLY_PROTOCOL==2)   // in case of the onion protocol fire the second burst (four species around the middle species) immediately after the zeroth (single species in the middle)
            return true;
        if(JIS_counter==JIS_protocol.size()-1)    // if it is the last JIS burst then do not throw a new burst (do not stop the while loop prematurely in Simulate)
            return false;
        else   {
            Float T_next_burst = Delta_T * (JIS_counter+1);     // in case of TIME_COORDINATION interprete Delta_T as the (normalized, i.e. in units of (Cv)^-1) time interval between successive bursts
            return t>=T_next_burst ? true : false;
        }
    }
    
    void homogeneous_recalculate_assembly_rate(short n)  {
        homogeneous_total_rates[2] -= assembly_rates[n];
        assembly_rates[n] = reaction_parameter * assembly_possibilities[n].size();
        homogeneous_total_rates[2] += assembly_rates[n];
        total_rates[2] = homogeneous_total_rates[2] * active_particles[0];
    }
    void homogeneous_recalculate_wrong_assembly_rate(short n)  {
        homogeneous_total_rates[4] -= wrong_assembly_rates[n];
        wrong_assembly_rates[n] = wrong_reaction_parameter * wrong_assembly_possibilities[n].size();
        homogeneous_total_rates[4] += wrong_assembly_rates[n];
        total_rates[4] = homogeneous_total_rates[4] * active_particles[0];
    }
    void recalculate_homogeneous_total_rates()  {
    // recalculate total assembly rate
        homogeneous_total_rates[2] = accumulate(assembly_rates.begin(), assembly_rates.end(), 0.);
    // recalculate total wrong_assembly rate
        if(WRONG_BINDING)
            homogeneous_total_rates[4] = accumulate(wrong_assembly_rates.begin(), wrong_assembly_rates.end(), 0.);
    }
    void homogeneous_recalculate_total_rates()  {
        total_rates[0] = homogeneous_total_rates[0] * (CONSTANT_DELIVERY ? Heaviside(inactive_particles[0]) : inactive_particles[0]);
        total_rates[1] = homogeneous_total_rates[1]*active_particles[0]*(active_particles[0]-1);       // recalculate nucleation rate:
        total_rates[2] = homogeneous_total_rates[2]*active_particles[0];      // recalculate assembly rate: if only the number of particle changes homogeneously but not the binding possibilities of a "specific particle" the binding and wrong_binding rates are modified by dividing through the old concentration and multiplying with the new concentration.
        if(WRONG_BINDING)
            total_rates[4] = homogeneous_total_rates[4]*active_particles[0];      // recalculate wrong_assembly rate:
    }
    void homogeneous_burst()  {
        if(START_INACTIVE==true)
            inactive_particles[0] = N;
        else
            active_particles[0] = N;
        homogeneous_recalculate_total_rates();
    }
    void homogeneous_destroy_inactive_particle()  {
        --inactive_particles[0];
//        for(short i=0; i<number_species; ++i)
//            --inactive_particles[i];
        //        homogeneous_recalculate_activation_rate();
        total_rates[0] = homogeneous_total_rates[0] * (CONSTANT_DELIVERY ? Heaviside(inactive_particles[0]) : inactive_particles[0]);
    }

    void homogeneous_create_annihilate_active_particle(short s)  {    // s=1: one monomer is created; s=-1 one monomer is annihilated
        active_particles[0] += s;
        homogeneous_recalculate_total_rates();
    }
    
    void activation()  {       // function could generally be expressed by particle creation and annihilation operators, not just in the homogeneous case.
        if(HOMOGENIZATION)  {
            homogeneous_destroy_inactive_particle();
            homogeneous_create_annihilate_active_particle(1);
            return;
        }
        short n = rng.ChooseInd_respective_weights(activation_rates.begin(), activation_rates.end(), total_rates[0]);
        inactive_particles[n]--;
//        n = ChooseInd(number_species);      // switch particle species   !!!!!!!!!! REMOVE AGAIN !!!!!!!!!!!!!!!!
        active_particles[n]++;
        recalculate_activation_rate(n);
        for(short m : {n,up(n),left(n),back(n)})
            if(m!=-1)
                recalculate_nucleation_rate(m);
        recalculate_assembly_rate(n);
        recalculate_wrong_assembly_rate(n);
    }

    void create_annihilate_active_particle(short n, short s, short done=0)  {      // creates (s=1) or annihilates (s=-1) an active monomer of species n; done ==1/2 indicates that assembly_rate/wrong_assembly_rate does not need to be recalculated because it must be recalculated later anyway.
        // update nucleation and nucleation_rates
        if(HOMOGENIZATION)  {           // if homogenization is enabled, use homogeneous_destroy_inactive_particle instead
            homogeneous_create_annihilate_active_particle(s);
            return;
        }
        active_particles[n] += s;
        // recalculate nucleation rates
        for(short m : {n,up(n),left(n),back(n)})
            if(m!=-1)
                recalculate_nucleation_rate(m);
        // update activation rate if REGULATION==true
        if(done!=1)
            recalculate_assembly_rate(n);
        if(done!=2)
            recalculate_wrong_assembly_rate(n);
    }
    
    inline void add_assembly_possibility(short species, short complex_index)  {
        assembly_possibilities[species].push_back(complex_index);
        HOMOGENIZATION==true  ?  homogeneous_recalculate_assembly_rate(species)  :  recalculate_assembly_rate(species);
        if(TRACK_ATTACHABLES)
        complexes[complex_index].attachables[species].push_back(assembly_possibilities[species].size()-1);
    }
    
    void update_assembly_possibilities(const short complex_index, const short n) {    // call this when the complex with index complex_index has attached a new monomer n
        array<short,6> neighbors = {up(n),down(n),right(n),left(n),front(n),back(n)};
        for(short m : neighbors)
            if (m!=-1 && complexes[complex_index][m]==0)  {
                if(CONSTANT_POLYMERIZATION_RATE && complexes[complex_index].get_num_neighbors(m)>1)            // add only if number of neighbors is equal to 1 effectively creates a homogeneous polymerization rate that is independent on the number of neighbors a binding partilce has.
                    continue;
                add_assembly_possibility(m, complex_index);
            }
    }
    
    void nucleation()  {
        short n1;
        if(HOMOGENIZATION)    // use the rejection method for homogenization since this is probably more efficient in this case
            n1 = rng.ChooseInd_respective_weights_rejection_method(nucleation_rates.begin(), nucleation_rates.end(), nucleation_parameter*DIMENSION);
        else
            n1 = rng.ChooseInd_respective_weights(nucleation_rates.begin(), nucleation_rates.end(), total_rates[1]);
        array<int,3> nucleation_directions = {active_particles_neighbor(n1,1),active_particles_neighbor(n1,2),active_particles_neighbor(n1,3)};  // decide whether nucleation occurs with the lower neighbor or with the right neighbor or with the front neighbor of n1.
        short n2;
        switch(rng.ChooseInd_respective_weights(nucleation_directions.begin(),nucleation_directions.end()))  {
            case 0: n2 = down(n1); break;
            case 1: n2 = right(n1); break;
            default: n2 = front(n1); break;
        }
// update nucleation and nucleation_rates
        create_annihilate_active_particle(n1,-1);
        create_annihilate_active_particle(n2,-1);
        // previously:   if homogenization ==true do only destroy one set of active particles so that the number of active particles cannot become -1 if it is 1 before.
        
// update assembly and assembly_rates
 //       short complex_index = complexes.add(complex(number_species,n1,n2,&detachment_parameters));
        short complex_index = complexes.add();
        complex& comp = complexes[complex_index];
        if(comp.data.size()==0)    // if comp is still empty reserve and resize the space (and set the pointer to detachment_parameters)
            comp = complex(number_species,&detachment_parameters);
        comp.add(n1);     // add the two constituents to the complex
        comp.add(n2);
        update_assembly_possibilities(complex_index, n1);
        update_assembly_possibilities(complex_index, n2);
// update wrong_assembly and wrong_assembly_rate
    // TODO
// update decay and decay rate
        if(2<=critical_size)  {            // 2 is size of new complex (consisting of two subsequent particles)
            subcritical_complexes.push_back(complex_index);
            recalculate_decay_rate();
        }
        if(DETACHMENT)  {
            Dfloat detach_rate = comp.detachables.get_total_rate();
  //          recalculate_detachment_rate(detach_rate,detach_rate);
            detachment_complexes.add_event(complex_index, detach_rate, detachment_crossreference);
            recalculate_detachment_rate();
        }
    }
    
    void remove_complex(short complex_index=-1)  {        // remove complex from the system; used for JIS_MULTI_DIM to increase yield
        if(HOMOGENIZATION || TRACK_ATTACHABLES || DETACHMENT)     // not yet implemented for HOMOGENIZATION, TRACK_ATTACHABLES and DETACHMENT
            abort();
        while(complex_index==-1)   {        // randomly pick a complex if not provided
            complex_index = rng.ChooseInd(complexes.size());
            if(complexes[complex_index].size==0)       // if complex doesn't exist set complex_index=-1 and repeat
            complex_index = -1;
        }
        complex& comp = complexes[complex_index];
        for(short i=0; i<number_species; ++i)           // delete assembly possibilities of the corresponding complex // better use delete_all_assembly_possibilities here if this function will be needed again.
            if(comp[i]==false)  {
                short nn = comp.get_num_neighbors(i);       // number of neighbors
                if (nn==1 || (nn>0 && CONSTANT_POLYMERIZATION_RATE))
                    VecDel_element(assembly_possibilities[i], complex_index);
                else if(nn>1)
                    VecDel_element_all(assembly_possibilities[i], complex_index);
                recalculate_assembly_rate(i);
            }
        if(comp.size <= critical_size)  {           // delete from subcritical_complexes if complex is subcritical
            VecDel_element(subcritical_complexes,complex_index);
            recalculate_decay_rate();
        }
        complexes.Delete(complex_index);
    }
    
    void complete_complex(short complex_index)  {
        if(critical_size>=number_species)  {    // if all complexes are unstable (subcritical) remove the reference on the complex from 'subcritical_complexes' and recalculate the decay rate.
            VecDel_element(subcritical_complexes,complex_index);
            recalculate_decay_rate();
        }
        if(DETACHMENT)    {     
    //        recalculate_detachment_rate(-complexes[complex_index].detachables.get_total_rate(), 0);
    //        VecDel_element(detachment_complexes, complex_index);
            detachment_complexes.remove_event(complexes[complex_index].type, complexes[complex_index].ind, detachment_crossreference);
            recalculate_detachment_rate();
        }
        complete_structures++;
   // TODO     number_defects.push_back(complexes[complex_index][3]);          // save the respective number of defects
        complexes.Delete(complex_index);
    }
    
    inline void delete_assembly_possibility(short species, short complex_index)   {     // delete one assembly possibiity of species 'species' in complex 'complex_index' assuming TRACK_ATTACHABLES is enabled.
        vector<short>& assembly_poss = assembly_possibilities[species];     // create reference to the respective vector
        short ind = complexes[complex_index].attachables[species].back();    // index referencing in assembly_possibilities
        VecDel_index(assembly_poss, ind);
        if(ind!=assembly_poss.size())
            exchange_in_vec(complexes[assembly_poss[ind]].attachables[species], short(assembly_poss.size()), ind, -1);   // VecDel_index changes the position of the last entry to the one of the deleted entry; therefore correct the reference in the shifted complex with index assembly_possibilities[species][ind] accordingly; (searchin gthe vector in forward or backward direction does not matter here but is important in 'track_attachable_delete()')
        complexes[complex_index].attachables[species].pop_back();
    }
    
    void delete_all_assembly_possibilities(short complex_index, short species, short ind=-1)  {      // delete all assembly possibilities of species 'species' in complex 'complex_index'. If TRACK_ATTACHABLES in disabled, it is assumed that the index of one entry in assembly_possibilities is provided (see 'assembly()'); ind is not used when TRACK_ATTACHABLES is enabled.
        if(TRACK_ATTACHABLES)   {
            vector<short>& assembly_poss = assembly_possibilities[species];     // create reference to the respective vector
            for(short ind : complexes[complex_index].attachables[species])  {
                VecDel_index(assembly_poss, ind);
                if(ind!=assembly_poss.size())  // correct the reference only if not the last element has been deleted
                exchange_in_vec(complexes[assembly_poss[ind]].attachables[species], short(assembly_poss.size()), ind, -1);      // VecDel_index changes the position of the last entry to the one of the deleted entry; therefore correct the reference in the shifted complex with index assembly_possibilities[n][ind] accordingly; it is important to search the vector in inverse direction otherwise it may come to complications in 3D if all three references point to the three last entries in assembly_possibilities;
            }
            complexes[complex_index].attachables[species].clear();     // earase this to free memory
        }
        else if(TRACK_ATTACHABLES==false)  {
            VecDel_index(assembly_possibilities[species], ind);
            if(CONSTANT_POLYMERIZATION_RATE==false)  {
                short num_neighbors = complexes[complex_index].get_num_neighbors(species);     // if the particle has more binding sites delete also the remaining ones
                if (num_neighbors==2)     //
                    VecDel_element(assembly_possibilities[species], complex_index);
                else if (num_neighbors>2)
                    VecDel_element_all(assembly_possibilities[species], complex_index);
            }
        }
    }
    
    void assembly()  {
        // particle n assembles to complex comlex_index
        Float total_rate = total_rates[2];
        if(HOMOGENIZATION)
            total_rate /= active_particles[0];
        short n = rng.ChooseInd_respective_weights(assembly_rates.begin(), assembly_rates.end(), total_rate);
        short ind = rng.ChooseInd(assembly_possibilities[n].size());
        short complex_index = assembly_possibilities[n][ind];
        complex& comp = complexes[complex_index];
        // delete assembly possibilities
        delete_all_assembly_possibilities(complex_index,n,ind);
        if(HOMOGENIZATION)        // if HOMOGENIZATION==false the assembly rate is updated in create_annihilate_active_particle
            homogeneous_recalculate_assembly_rate(n);
        // if ring size is going to be supercritical after assembly but has been subcritical before delete it from subcritical_complexes
        if(comp.size==critical_size)  {
            VecDel_element(subcritical_complexes,complex_index);
            recalculate_decay_rate();
        }
        // add particle to the complex, destroy active particle
        comp.add(n);
        create_annihilate_active_particle(n,-1);
        if(DETACHMENT)  {
            detachment_complexes.change_rate(complex_index, comp.type, comp.ind, comp.detachables.get_total_rate(), detachment_crossreference);
            recalculate_detachment_rate();
        }
    //        recalculate_detachment_rate(detachment_rate_increment, complexes[complex_index].detachables.get_total_rate());
        // if complex is complete remove it via complete complex otherwise update assembly possibilities
        if (comp.size==number_species)  {
            complete_complex(complex_index);
            return;
        }
        update_assembly_possibilities(complex_index,n);
    }

    void detachment(short complex_index=-1)  {
        if(complex_index==-1)
            complex_index = detachment_complexes.choose_event(rng);
        complex& comp = complexes[complex_index];
  //      if(comp.size==0)
        if(comp.detachables.get_num_events()==0)     // very rarely it may happen due to numerical errors resulting from incrementing the rates that a complex with size 0 is selected. In that case just return.
            return;
        short n = comp.detachables.choose_event(false,rng);      // don't delete the event now but later in comp.remove() (could be done here as well however)
  //      short n = comp.detachables[rng.ChooseInd(num_detachables)];
        for(short m : {up(n),down(n),right(n),left(n),front(n),back(n)})  {
            if (m!=-1)  {
                if(comp[m])
                    add_assembly_possibility(n,complex_index);
                else  {
                    if(CONSTANT_POLYMERIZATION_RATE==false || comp.get_num_neighbors(m) > 1)     // do not delete the assembly possibility if CONSTANT_POLYMERIZATION_RATE==true and site m still has at least one neighbor after site n has detached.
                        delete_assembly_possibility(m, complex_index);
                    HOMOGENIZATION  ?  homogeneous_recalculate_assembly_rate(m)  :  recalculate_assembly_rate(m);
                }
            }
        }
        if(HOMOGENIZATION)        // if HOMOGENIZATION==false the assembly rate is updated in create_annihilate_active_particle
            homogeneous_recalculate_assembly_rate(n);
        comp.remove(n);
        detachment_complexes.change_rate(complex_index, comp.type, comp.ind, comp.detachables.get_total_rate(), detachment_crossreference);
        recalculate_detachment_rate();
  
        create_annihilate_active_particle(n,1);
        // if only a monomer remains call detachment again to detach also the monomer. If the complex is empty after the second detachment, release the complex from 'complexes'.
        if(comp.size==1)
            detachment(complex_index);
        else if(comp.size==0)
            complexes.release(complex_index);
    }
    
    void wrong_assembly()  {abort();};      // not yet implemented
    void decay_complex()  {abort();};       // not yet implemented
    
    void plot_JIS_deficiency()  {      // only relevant for 2D JIS supply, to be called at the end of the simulation (e.g. when the final yield is calculated) for each species print the number of complexes that break up at that species. This may help detect deficiencies in the supply and optimize the supply via protocol_numbers.
        vector<short> statistics(number_species,0);
        for(complex& comp : complexes)
            if(comp.size>0 && comp[JIS_protocol[0][0]]==1)     // only consider existing complexes that comprise the first protocol element (i.e. that have normally started (and are not the result of undesired dimerization)) and now register the elements of these complexes that are missing.
                for(short i=0; i<number_species; ++i)
                    if(comp[i]==0)
                        ++statistics[i];
    // print statistics
        dimensionality_plot(statistics, 6);
    }
    
    void plot_dimerization_seeds()  {      // only relevant for 2D JIS supply, to be called at the end of the simulation (e.g. when the final yield is calculated) print the statistical weights of the dimerization seeds.
        vector<short> statistics(number_species,0);
        for(complex& comp : complexes)
            if(comp.size>0 && comp[JIS_protocol[0][0]]==0)   {    // only consider existing complexes that do not comprise the first protocol element (i.e. that have NOT normally started (and are thus the result of undesired dimerization)) and now register the elements of lowest protocol index, i.e. the species that was responsible for their dimerization.
                short min = number_species, min_spec = 0;
                for(short i=0; i<number_species; ++i)
                    if(comp[i]==1 && C[i]<min) {
                        min = C[i];
                        min_spec = i;
                    }
                ++statistics[min_spec];
            }
        // print statistics
        dimensionality_plot(statistics, 6);
    }
    
    void print_growth_ratio()    {        // if DETACHMENT==true, calculates the average ratio between the number of attachables and detachables for each complex size. This ratio can inform about the efficiency of the convention of "detachable" in the reversible binding scenario. Optimally the ratio should increase with increasing size of the complex. If in contrast it decreases, the smaller structures grow faster and the reversible binding scenario is very inefficient.
        vector<Float> growth_ratios(number_species,0.);
        vector<short> numbers(number_species,0);
        for(complex& comp : complexes)  {
            if(comp.size>0)  {
                short attachables = 0;
                for(short i=0; i<number_species; ++i)
                    attachables += comp.attachables[i].size();
                growth_ratios[comp.size] += Float(attachables)/comp.detachables.get_total_rate();
                ++numbers[comp.size];
            }
        }
        for(short i=0; i<number_species; ++i)
            cout << growth_ratios[i]/numbers[i]  << "  ";
        cout << endl;
    }
    
    Float calculate_yield()  {
            return (Float) complete_structures*number_species/N_tot;
    }
    
    void calculate_yield_advanced(array<Float,3>& yield_advanced)  {
        yield_advanced[0] = (Float) complete_structures*number_species/N_tot;        // yield of completed rings (with and without defects)
        yield_advanced[1] = (Float) count(number_defects.begin(), number_defects.end(), 0)*number_species/N_tot;     // yield of completed rings without defects
        yield_advanced[2] = complete_structures + complexes.content();       // number of complexes which can be used e.g. to calculate the average dimerization probability in the JIS scenario
        if(PRINT_JIS_PROTOCOL) {
            plot_JIS_deficiency();
            plot_dimerization_seeds();
        }
    }
    
public:
    class Make_Complex_Statistics;      // declare class in order to be able to use it as argument in "Simulate"
    long long Simulate(Make_Complex_Statistics& Make_Complex_Stats, Float* yield, array<Float,3>* yield_advanced = NULL, double* T = NULL, double* T50 = NULL, double* T90 = NULL)  {     // T50 and T90 denote the time point when 50% and 90% yield is reached for the first time
        initialize();
        Make_Complex_Stats(0);          // after initialize() call Make_Complex_Stats() so that the inactive states are counted correctly
        short n = 0;   // counter for the bursts
        double t = 0.;
        long long steps = 0;
        int activation_steps = 0;
        long long refresh_rates = 1000;       // always after refresh_rates steps recalculate all total rates so that numerical errors do not mess up the total rates
//        Make_Complex_Statstics Make_Complex_Stats(*this, Complex_Statistics, false, 1000);
        short complete_structures_50 = ceil(0.5*N_tot/number_species);
        short complete_structures_90 = ceil(0.9*N_tot/number_species);
        *T50=-1;
        *T90=-1;
        
        do {
            if(n>0)  {    // burst only if it's not the first run, otherwise initialize() has done the part of the (first) burst()
                burst(n);       // if BURSTS_ADVANCED==true automatically calls burst_advanced
                if(TIME_COORDINATION)    // in case of TIME_COORDINATION, if t < the time point of the burst (if all particles of the previous burst have bound and the while loop has stopped because the total rate has gone to zero) set t to the time point of the burst
                    t = n==0 ? 0 : Delta_T*(n-1);
                Make_Complex_Stats(0);      // after each burst call Make_Complex_Stats() so that the inactive states are counted correctly
            }
            Float total_rate = accumulate(total_rates.begin(), total_rates.end(), Float(0.0));
            Float minimal_activation_rate = 0.5*activation_parameters[0];
            Float minimal_detachment_rate = 0.5*(*nonzero_min(detachment_parameters.begin(), detachment_parameters.end()));
            while((total_rate-total_rates[5])>1e-6 || total_rates[0]>minimal_activation_rate || total_rates[5]>minimal_detachment_rate)  {
                // update time
                t -= log(rng.UnifRand())/total_rate;
                if(JIS_MULTI_DIM && (TIME_COORDINATION ? new_JIS_burst_time(n, t) : new_JIS_burst_average(n)))
                    break;
                ++steps;
   //                 print_growth_ratio();
                // choose event
                short d = rng.ChooseInd_respective_weights(total_rates.begin(), total_rates.end(), total_rate);
                
                switch(d) {
                    case 0:
                        activation();
                        Make_Complex_Stats(++activation_steps);
                        break;
                    case 1:
                        nucleation();
                        break;
                    case 2:
                        assembly();
                        break;
                    case 3:
                        decay_complex();
                        break;
                    case 4:
                        wrong_assembly();
                        break;
                    case 5:
                        detachment();
                        break;
                }
                // calculate new total_rate
                total_rate = accumulate(total_rates.begin(), total_rates.end(), Float(0.0));
                if(steps>refresh_rates)  {
                    recalculate_total_rates();
                    refresh_rates += 1000;
                }
                if(ADVANCED_TIME_MEASUREMENT && complete_structures>=complete_structures_50 && *T50==-1)
                    *T50=t;
                if(ADVANCED_TIME_MEASUREMENT && complete_structures>=complete_structures_90 && *T90==-1)
                    *T90=t;
     //           if(complete_structures >= complete_structures_max_yield)
     //               break;
                if(DETACHMENT && (complete_structures>=complete_structures_90 || steps>maximum_number_steps || t>T_max))   //        // if DETACHMENT enabled break up if a yield of 90% is achieved or if more than maximum_number_steps are needed in order to avoid getting stuck in kinetic traps.
                    break;
                if(DETACHMENT && HOMOGENIZATION)    // if fewer particles are left than would be needed to form a stable nucleus and all other particles are stably bound break up. Otherwise these left particles will bind and detach forever.
                    if(total_rates[5]<minimal_detachment_rate && (inactive_particles[0]+active_particles[0])<2)
                        break;
                // perform tests if NDEBUG is not defined
    #if MY_DEBUG_LEVEL >= 2
          //      check_track_attachables();
                HOMOGENIZATION ? homogeneous_test_all() : test_all(n);
    #endif
            }
        } while(++n < n_bursts);
        Make_Complex_Stats.close();         // only important if BURSTS_ADVANCED==true since then still unoccupied positions in the complex statistics must be filled.
        *yield = calculate_yield();
//        if(WRONG_BINDING)
            calculate_yield_advanced(*yield_advanced);
        *T = t;
//        Make_Complex_Statistics();
        return steps;
    }

    void Simulate(short times, short Complex_Statistics_Level, Float* yield_mean, Float* yield_var, double* T_mean = NULL, array<Float,3>* yield_advanced_mean = NULL,  double* T50_mean = NULL, double* T90_mean = NULL)  {
        vector<Float> yield(times,0.);
        vector<array<Float,3>> yield_advanced;
        yield_advanced.resize(times);
        vector<double> T(times,0.);
        vector<double> T50(times,0.);
        vector<double> T90(times,0.);
        class Make_Complex_Statistics Make_Complex_Stats(*this, Complex_Statistics_Level, false, STEP_ComplexStatistics);
        for(short g=0; g<times; ++g)  {
            long long steps = Simulate(Make_Complex_Stats, &yield[g], &yield_advanced[g], &T[g], &T50[g], &T90[g]);
            if(SUPPRESS_IMMEDIATE_OUTPUT==false)   {
                cout << "steps needed: " << steps << endl;
                cout << "yield: " << yield[g] << "  time: " << T[g];
                if(ADVANCED_TIME_MEASUREMENT)
                    cout << "  T50: " << T50[g] << "  T90: " << T90[g];
                cout << endl;
            }
            if(BREAK && g==2)   {               // if break is set true and the first three runs give yield 0 break up (because all other runs will very likely also give yield 0)
                if(yield[0]==0 && yield[1]==0 && yield[2]==0)  {
                    times = 3;
                    break;
                }
                if(yield[0]>=UPPER_BREAK && yield[1]>UPPER_BREAK && yield[2]>UPPER_BREAK)  {
                    times = 3;
                    break;
                }
            }
        }
   Make_Complex_Stats.print_to_file("/Users/F.Gartner/Documents/Complex_Statistics_Data.txt",times);
        *yield_mean = accumulate(yield.begin(), yield.end(), 0.)/times;
        *yield_var = accumulate(yield.begin(), yield.end(), 0., [](Float x, Float y){return x + y*y;})/times - (*yield_mean)*(*yield_mean);
        *T_mean = accumulate(T.begin(), T.end(), 0.)/times;
        cout << "average yield = " << *yield_mean << "      average time needed = " << *T_mean;
        if(ADVANCED_TIME_MEASUREMENT)  {
            short counter=0;
            *T50_mean = accumulate(T50.begin(), T50.end(), 0.,[&counter](double a, double b){if(b!=-1) {++counter; return a+b;} else return a;});
            *T50_mean = (counter<0.5*times) ? -1 : *T50_mean/counter;
            counter=0;
            *T90_mean = accumulate(T90.begin(), T90.end(), 0.,[&counter](double a, double b){if(b!=-1) {++counter; return a+b;} else return a;});
 //           *T90_var = accumulate(T90.begin(), T90.end(), 0., [](Float x, Float y){return x + y*y;})/times - (*T90_mean)*(*T90_mean);
            *T90_mean = (counter<0.5*times) ? -1 : *T90_mean/counter;
            cout << "  average T50: " << *T50_mean << "  average T90: " << *T90_mean;
        }
//        if(WRONG_BINDING)  {
            *yield_advanced_mean = accumulate(yield_advanced.begin(), yield_advanced.end(), array<Float,3> {0.,0.,0.}, [](array<Float,3>& a, array<Float,3>& b){return a+b;});
            (*yield_advanced_mean)[0]/=times;
            (*yield_advanced_mean)[1]/=times;
            (*yield_advanced_mean)[2]/=times;
        cout << "   av number of complexes: " << (*yield_advanced_mean)[2];
 //       }
        cout << endl;
    }

    
/////////////////////////////////// Observables /////////////////////////////////////////////////////
    typedef int sint;
    class Make_Complex_Statistics  {
        System& system;
        vector<int> ActTime;    // saves the time points where complex statistics are measured; time is usually measured in units of activation events, so e.g. ActTime[5] = 6000 means at that the 6th measurement that is saved as the 6th element in Complex_Statistics_simple or Complex_Statistcs_detailed, resp. was after the 6000th activation event;
        vector<sint> Complex_Statistics_simple;            // only needed if LEVEL==0
        vector<vector<sint>> Complex_Statistics_detailed;  // only needed if LEVEL==1 or LEVEL==2
        int reserve_size;      // size to reserve for ActTime and Complex_Statistics (number of measurements)
        const short LEVEL;    // level of description of complex statistics: LEVEL==-1 do nothing; LEVEL==0 save/print only the total number of complexes; LEVEL==1 save/print total number of complexes of each size (L values per time step);
        const bool OUTPUT;    // output for each call of Make_Complex_Statistics yes(1) or no(0)
        const short STEP;     // step size
        int h;
        
    public:
        Make_Complex_Statistics(System& system, short LEVEL, bool OUTPUT, short STEP_) : system(system),LEVEL(LEVEL),OUTPUT(OUTPUT),STEP(STEP_ == -1 ? system.n_bursts*system.N*system.number_species/2000 : STEP_)  {  // for meaning of parameters see definition of class members  // !!!
            if(LEVEL==-1)
                return;
            reserve_size = system.N*system.number_species*system.n_bursts/STEP+1;
            ActTime.resize(reserve_size,0);
            for(short i=0;i<reserve_size;++i)
                ActTime[i] = i*STEP;
            if(LEVEL==0)
                Complex_Statistics_simple.resize(reserve_size,0);
            else if(LEVEL==1)
                Complex_Statistics_detailed.resize(reserve_size,vector<sint>(system.number_species+1,0));
            h = 1;
        }
        void operator() (int activation_step)  {
            if(LEVEL==-1)
                return;
            if(activation_step==0)      // reset h if the begin of a new run is detected
                h=0;
            if(h*STEP==activation_step)  {
     //           ActTime.push_back(activation_step);
                if(LEVEL==0)        // distinguishing the LEVEl of the statistics push_back enough space and fill in the corresponding statistics
                    system.Make_Complex_Statistics(LEVEL, OUTPUT, &Complex_Statistics_simple[h]);
                else if(LEVEL==1)
                    system.Make_Complex_Statistics(LEVEL, OUTPUT, &Complex_Statistics_detailed[h].front());
                h++;
            }
        }
        void close() {          // fill up all missing entries in Complex_Statistics even if the final state is already reached (in order to get the right average)
            if(LEVEL==-1)
                return;
            while(h<reserve_size)
                    operator()(STEP*h);
        }
        void print_to_file(string filename, short sample_size)  {      // print the whole complex statistics (for all measured time steps) to a file
            if(LEVEL==-1)
                return;
            ofstream file(filename);
            if(file.is_open())  {
                file << ActTime.size() << endl;
                for(int t : ActTime)
                    file << t << "  ";
                file << endl << endl;
                if(LEVEL==0)  {
                    file << Complex_Statistics_simple.size() << "  " << endl;
                    for(sint c : Complex_Statistics_simple)
                        file << fixed << setprecision(2) << (Float)c/sample_size << "  ";
                }
                else  {
                    file << Complex_Statistics_detailed.size() << "  " << Complex_Statistics_detailed[0].size() << endl;
                    for(vector<sint>& vec : Complex_Statistics_detailed)  {
                        for(int i=0; i<vec.size(); ++i)
                            file << fixed << setprecision(2) << (Float)vec[i]/sample_size << "  ";
                        file << endl;
                    }
                }
            }
            else
                cout << "could not open file/n";
            file.close();
        }
    };
    
    void Make_Complex_Statistics(short LEVEL, bool OUTPUT, sint* Complex_Statistics)  {        // takes a pointer to a short starting from which it fills in the complex statistics at the current time, distinguishing three levels of the statistics: LEVEL==0 save/print only the total number of complexes (1 value); LEVEL==1 save/print total number of each complex size (L values); LEVEl==2 save/print number of each complex type (species and size) (L*number_species values)
        if(LEVEL==0)  {
            *Complex_Statistics += complete_structures;   // to count only the complete rings instead of complexes !!!
            if(OUTPUT)
                cout << "total number of complexes: " << *Complex_Statistics << endl;
        }
        if(LEVEL==1)  {
            Complex_Statistics[0] += accumulate( inactive_particles.begin(), inactive_particles.end(), (sint)0 ); // put inactive and active particles on 0th and 1st entry of Complex_Statistics
            Complex_Statistics[1] += accumulate( active_particles.begin(), active_particles.end(), (sint)0 );
            for(int i=0; i<complexes.size(); ++i)  {
                if(complexes[i].size!=0)
                    Complex_Statistics[complexes[i].size]++;
            }
            Complex_Statistics[number_species] += complete_structures;
            
            if(OUTPUT)  {
                for(short i=0; i<=number_species; ++i)
                    cout << Complex_Statistics[i] << "  ";
                cout << endl;
                cout << "total number of complexes: " << complexes.content() << endl;
            }
        }
    }
    
/////////////////////////////////// Tests /////////////////////////////////////////////
#if MY_DEBUG_LEVEL >= 2
    Float eps = 1e-5;     // relative error tolerance for the total rates (which might be rather large values)
    template<class T>       // check if val is contained num times in vector vec
    bool check_contained(const vector<T>& vec, T val, short num=1)  {
        auto it = vec.begin()-1;
        for(short i=0; i<num; ++i)  {
            it = find(it+1, vec.end(), val);
            if(it==vec.end())
                return false;
        }
        return true;
    }
    template<class T>       // check if two or more duplicates are contained in the vector vec
    bool check_contains_duplicates(vector<T>& vec)  {
        for(short i=0; i<vec.size(); ++i) {
            T val = vec[i];
            for(short j=i+1; j<vec.size(); ++j)
                if(vec[j]==val)
                    return true;
        }
        return false;
    }
    void check_active_particles()  {
        for(short i=0; i<number_species; ++i)
            assert(active_particles[i]>=0);
    }
    void check_activation_rates()  {        // check if all activation rates are consistent and if they add up to 'total_activation_rate'
        for(short i=0; i<number_species; ++i)  {
            Float activation_rate;
            if(CONSTANT_DELIVERY)
                activation_rate = inactive_particles[i]>0  ?  N*activation_parameters[i] : 0;
            else
                activation_rate = inactive_particles[i]*activation_parameters[i];
            assert(abs(activation_rate-activation_rates[i])<1e-5);
        }
        Float dev = abs(accumulate(activation_rates.begin(),activation_rates.end(),0.)-total_rates[0]);
        assert(dev<=max(eps*total_rates[0],eps));       // compare dev to either a relative or an absolute tolerance if total_rates[i]<1
    }
    void check_nucleation_rates()  {    // check if all nucleation rates are consistent and if they add up to 'total_nucleation_rate'
        for(short i=0; i<number_species; ++i)  {
            Float nucleation_rate = 0;
            for(short m : {right(i),down(i),front(i)})
                if (m!=-1)
                    nucleation_rate += nucleation_parameter*active_particles[i]*active_particles[m];
            assert(abs(nucleation_rate-nucleation_rates[i])<=1e-5);
        }
        Float dev = abs(accumulate(nucleation_rates.begin(),nucleation_rates.end(),0.)-total_rates[1]);
        assert(dev<=max(eps*total_rates[1],eps));
    }
    void check_assembly_rates()  {      // check if all assembly rates are consistent and if they add up to 'total_assembly_rate'
        for(short i=0; i<number_species; ++i)  {
            Float assembly_rate = reaction_parameter*active_particles[i]*assembly_possibilities[i].size();
            assert(abs(assembly_rate-assembly_rates[i])<1e-5);
        }
        Float dev = abs(accumulate(assembly_rates.begin(),assembly_rates.end(),0.)-total_rates[2]);
        assert(dev<=max(eps*total_rates[2],eps));
    }
    void check_wrong_assembly_rates()  {      // check if all assembly rates are consistent and if they add up to 'total_assembly_rate'
        for(short i=0; i<number_species; ++i)  {
            Float wrong_assembly_rate = wrong_reaction_parameter*active_particles[i]*wrong_assembly_possibilities[i].size();
            assert(abs(wrong_assembly_rate-wrong_assembly_rates[i])<1e-5);
        }
        Float dev = abs(accumulate(wrong_assembly_rates.begin(),wrong_assembly_rates.end(),0.)-total_rates[4]);
        assert(dev<=max(eps*total_rates[4],eps));
    }
    void check_assembly_possibilities()  {
        for(short i=0; i<number_species; ++i)  {            // check if all complexes referenced from 'assembly_possibilities' are indeed complexes which have the correct boundaries
            for(short complex_index : assembly_possibilities[i])
                assert(complexes[complex_index][i]==0 && complexes[complex_index].get_num_neighbors(i)>0);
        }
    }
    void check_wrong_assembly_possibilities()  {}   // TODO!!
    
    void check_subcritical_complexes()  {
        for(short i=0; i<complexes.size(); ++i)  {  // check if rings with subcritical size are actually referenced in 'subcritical_complexes'
            if(complexes[i].size!=0)     // check if complex actually exists
                if(complexes[i].size<=critical_size)
                    assert(check_contained(subcritical_complexes,i));
        }
        for(short complex_index : subcritical_complexes)    // check if all complexes listed in 'subcritical_complexes' have actually subcritical size
            assert(complexes[complex_index].size<=critical_size);
        assert(abs(subcritical_complexes.size()*decay_parameter-total_rates[3])<=max(eps*total_rates[3],eps));    // check if total_decay_rate is consistent
    }
    short recalculate_size(complex& Complex)  {       // recaluclate the size of a complex
        short size = 0;
        for(short i=0; i<number_species; ++i)
            size += Complex[i];
        return size;
    }
    void check_complexes()  {
        for(short i=0; i<complexes.empty.size(); ++i)
            assert(complexes[complexes.empty[i]].size==0);
        for(short i=0; i<complexes.size(); ++i)  {
            if(complexes[i].size==0)
                assert(check_contained(complexes.empty,i));
            else            // check if complex size is consistent
                assert(recalculate_size(complexes[i])==complexes[i].size);
        }
    }
    void check_mass_conservation(short JIS_counter)  {       // check particle number conservation; does not work if there are more than one burst or (even only a single) advanced burst;
        int total_number = accumulate(inactive_particles.begin(),inactive_particles.end(),0) + accumulate(active_particles.begin(),active_particles.end(),0);
        for(short i=0;i<complexes.size(); ++i)
            total_number += complexes[i].size;      // add size of unfinished complexes minus their number of defects
        total_number += complete_structures*number_species;
        for(short i=0; i<number_defects.size(); ++i)       // subtract defects in completed rings
            total_number -= number_defects[i];
        if(JIS_MULTI_DIM)  {        // if JIS supply via bursts is enabled count the number of species that have already been provided
            short k=0;
            for(short i=0; i<=JIS_counter; ++i)
                k+=JIS_protocol[i].size() * JIS_protocol_numbers[i];
            assert(total_number==k);
        }
        else
            assert(total_number==N*number_species);
    }
    void check_track_attachables()  {
        for(short complex_index=0; complex_index<complexes.size(); ++complex_index)  {     // check if all entries in attachables contain a reference to an entry in assembly_possibilities indicating the corresponding complex_index
            complex& comp = complexes[complex_index];
            if(comp.size==0)
                continue;
            for(short i=0; i<number_species; ++i)  {
                assert(check_contains_duplicates(comp.attachables[i])==false);     // check if attachables contains duplicates
                for(short index : comp.attachables[i])
                    assert(assembly_possibilities[i][index]==complex_index);
            }
        }
        for(short i=0; i<number_species; ++i)      // other way round: for each complex_index in assembly_possibilities check if there is an entry in attachables of the corresponding complex referencing to the entry in assebmly_possibilities
        for(short j=0; j<assembly_possibilities[i].size(); ++j)  {
            short complex_index = assembly_possibilities[i][j];
            assert(check_contained(complexes[complex_index].attachables[i],j));
        }
    }
    short get_num_neighbors_debug(complex& comp, short n)  {
        array<short,6> neighbors = {up(n),down(n),right(n),left(n),front(n),back(n)};
        short sum = 0;
        for(short m : neighbors)
            if(m!=-1 && comp.data[m])
                ++sum;
        return sum;
    }
    void check_num_neighbors(complex& comp)   {        // called from check_detachment_complexes
        for(short n=0; n<number_species; ++n)
            assert(comp.num_neighbors[n] == get_num_neighbors_debug(comp,n));
    }
    void check_detachables(complex& comp)  {     // called from check_detachment_complexes
        for(short n : vector<short>(comp.detachables))    // check if each detachable has detachment rate larger than 0
            assert(comp.detachment_rate(n, comp.num_neighbors[n]) > 0);
        for(short n=0; n<comp.num_neighbors.size(); ++n)   // check for each species with detachment rate larger than 0 that it is contained in 'detachables'.
            if(comp[n] && (comp.detachment_rate(n, comp.num_neighbors[n])>0))  {
  //              short num = DETACHMENT==1  ?  1 : neighbor_stabilization[n]-comp.num_neighbors[n];
   //            short num = comp.detachment_rate(n, comp.num_neighbors[n]);
                assert(check_contained(vector<short>(comp.detachables),n));
            }
    }
    void check_detachment_complexes()  {
        Dfloat total_rate_debug = 0;
        Dfloat max_rate_debug = 0;
        // check if total detachment rate and overall maximal detachment rate are consistent with 'complexes'
        for(complex& comp : complexes)
            if(comp.size>0)  {
                check_num_neighbors(comp);
                check_detachables(comp);
                Dfloat detachment_rate = comp.detachables.get_total_rate();
                total_rate_debug += detachment_rate;
                if(detachment_rate>max_rate_debug)
                    max_rate_debug = detachment_rate;
            }
        Dfloat dev = abs(total_rate_debug-total_rates[5]);
        assert(dev<=max(eps*total_rates[5],eps));
        if(detachment_complexes.events.size()>0 && max_rate_debug>0)
            assert(max_rate_debug<=*max_element(detachment_complexes.maximal_rates.begin(), detachment_complexes.maximal_rates.end()) );
    // check consistency of total_rates and maximal_rates within 'detachment_complexes'
        for(short i=0; i<detachment_complexes.rates.size(); ++i)   {
            total_rate_debug = accumulate(detachment_complexes.rates[i].begin(), detachment_complexes.rates[i].end(), 0.);
            max_rate_debug = *max_element(detachment_complexes.rates[i].begin(), detachment_complexes.rates[i].end());
            Dfloat dev = abs(total_rate_debug-detachment_complexes.total_rates[i]);
            assert(dev<=max(eps*detachment_complexes.total_rates[i],eps));
            assert(max_rate_debug<=detachment_complexes.maximal_rates[i] );
        }
        // check if detachment rates in detachment_complexes correspond to those in complexes and the type and index in 'complex' refer to the correct address in 'detachment_complexes'
        for(short i=0; i<detachment_complexes.rates.size(); ++i)
            for(short j=0; j<detachment_complexes.rates[i].size(); ++j)  {
                Float detach_rate = complexes[detachment_complexes.events[i][j]].detachables.get_total_rate();
                assert(detachment_complexes.rates[i][j]==detach_rate);
                int event = detachment_complexes.events[i][j];
                assert(complexes[event].type==i);
                assert(complexes[event].ind==j);
            }
    }
    void test_all(short JIS_counter)  {
        check_active_particles();
        check_activation_rates();
        check_nucleation_rates();
        check_assembly_rates();
        check_assembly_possibilities();
        if(WRONG_BINDING) {
            check_wrong_assembly_rates();
            check_wrong_assembly_possibilities();
        }
        check_subcritical_complexes();
        check_complexes();
        check_detachment_complexes();
        check_mass_conservation(JIS_counter);          // use this only in combination with a single, non-advanced burst!!
        if(TRACK_ATTACHABLES)
            check_track_attachables();          // warning: extremely computationally costy
    }
    
// homogeneous tests
    void homogeneous_check_particles()  {
        assert(active_particles[0]>=0);
        assert(inactive_particles[0]>=0);
        for(short i=1; i<number_species; ++i)  {
            assert(active_particles[i]==0);
            assert(inactive_particles[i]==0);
        }
    }
    void homogeneous_check_activation_rates()   {
        Float activation_rate = activation_parameters[0] * (CONSTANT_DELIVERY ? N : 1);
        for(short i=0; i<number_species; ++i)
            assert(abs(activation_rate-activation_rates[i])<1e-5);
        assert(abs(homogeneous_total_rates[0]-number_species*activation_rate)<1e-5);
        Float total_rate = homogeneous_total_rates[0]*(CONSTANT_DELIVERY ? Heaviside(inactive_particles[0]) : inactive_particles[0]);
        assert(abs(total_rates[0]-total_rate) < 1e-5);
    }
    void homogeneous_check_nucleation_rates()  {
        for(short i=0; i<number_species; ++i)  {
            Float homogeneous_nucleation_rate = 0;
            for(short m : {right(i),down(i),front(i)})
                if (m!=-1)
                    homogeneous_nucleation_rate += nucleation_parameter;
            assert(abs(homogeneous_nucleation_rate-nucleation_rates[i])<=1e-5);
        }
        assert(abs(accumulate(nucleation_rates.begin(),nucleation_rates.end(),0.)-homogeneous_total_rates[1])<1e-5);
        Float dev = abs(homogeneous_total_rates[1]*active_particles[0]*(active_particles[0]-1)-total_rates[1]);
        assert(dev<=max(eps*total_rates[1],eps));
    }
    void homogeneous_check_assembly_rates()  {
        for(short i=0; i<number_species; ++i)  {
            Float assembly_rate = reaction_parameter*assembly_possibilities[i].size();
            assert(abs(assembly_rate-assembly_rates[i])<1e-5);
        }
        Float dev = abs(accumulate(assembly_rates.begin(),assembly_rates.end(),0.)-homogeneous_total_rates[2]);
        assert(dev<=max(eps*homogeneous_total_rates[2],eps));
        dev = abs(homogeneous_total_rates[2]*active_particles[0]-total_rates[2]);
        assert(dev<=max(eps*total_rates[2],eps));
    }
    void check_mass_conservation_homogeneous()  {       // check particle number conservation; does not work if there are more than one burst or (even only a single) advanced burst;
 //       int total_number = accumulate(inactive_particles.begin(),inactive_particles.end(),0) + accumulate(active_particles.begin(),active_particles.end(),0);
        int total_number = inactive_particles[0] + active_particles[0];
        for(short i=0; i<complexes.size(); ++i)
            if(complexes[i].size > 0)
                total_number += complexes[i].size;      // add size of unfinished complexes minus their number of defects
        total_number += complete_structures*number_species;
        for(short i=0; i<number_defects.size(); ++i)       // subtract defects in completed rings
            total_number -= number_defects[i];
        assert(total_number==N);
    }
    
    void homogeneous_test_all()  {
        homogeneous_check_particles();
        homogeneous_check_activation_rates();
        homogeneous_check_nucleation_rates();
        homogeneous_check_assembly_rates();
        check_assembly_possibilities();
        if(WRONG_BINDING)
            abort();
        check_subcritical_complexes();
        check_complexes();
        check_detachment_complexes();     // no distinction between HOMOGENIZATION and non-HOMOGENIZATION
        check_mass_conservation_homogeneous();
    }
    
#endif
};




#endif /* System_hpp */
