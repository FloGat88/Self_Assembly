//
//  Preliminary.hpp
//  Self_Assembly
//
//  Created by Florian Gartner on 28/01/17.
//  Copyright © 2017 Florian Gartner. All rights reserved.
//

#ifndef Preliminary_hpp
#define Preliminary_hpp


#define MY_DEBUG_LEVEL 0   // MY_DEBUG_LEVEL >= 1 checks all stl containers for out-of-range-access. MY_DEBUG_LEVEL >= 2 also performs all the unit tests defined in the class System (see System.hpp).
// #define PARALLELIZE      // define the macro to enable parallelization (only when using ParameterSweep() or Hyper_Sweep())





#if MY_DEBUG_LEVEL == 0
#define NDEBUG
#endif


#if MY_DEBUG_LEVEL >= 1         // DebugVector and DebugArray must be included first so that all other headers which might include <vector> or <array>  do not mess debugging up by including the original versions
    #define LIBCPP_ASSERT(x, m) ((x) ? (void)0 : abort())      // macro that is used in DebugVector for out-of-range checking
    #include <iostream>
    #include "DebugVector.h"
    #include "DebugArray.h"             // in DebugArray explicit range checking is implemented by hand and uses iostream (therefore, iostream must me included before)
    #include <deque>                    // TODO: !!! implement the Debug Version of deque!!!
#else
    #include <array>
    #include <vector>
    #include <deque>
#endif

#include "RandomNumberGenerator.h"
#include "Utility.hpp"
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <limits>
#include <cfloat>
#include <list>
#include <algorithm>
#include <functional>
#include <string>
#include <fstream>
#include <sstream>
#include <assert.h>
#ifdef PARALLELIZE
    #include <thread>
#endif


using namespace std;


#endif /* Preliminary_hpp */


