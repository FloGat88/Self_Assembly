//  RandomNumberGenerator.h

#ifndef Self_Assembly_RandomNumberGenerator_h
#define Self_Assembly_RandomNumberGenerator_h

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cfloat>
#include <random>
#include <iostream>
#include <type_traits>
#include "Utility.hpp"

#if MY_DEBUG_LEVEL == 0
     #define RANDOM_SEED
#endif

#define short int
typedef double Float;
typedef double Dfloat;    // date type for detachment rates

using namespace std;

class RandonNumberGenerator {
private:
    mt19937 mt;                                          // random number generator defined in main.cpp
    uniform_real_distribution<double> randdouble;
    uniform_real_distribution<Float> randfloat;
    normal_distribution<Float> gaussfloat;
    double r;     // to enhance efficancy use the same random number several times in ChooseInd to "extract an index out of it"
    short count;

public:

        RandonNumberGenerator()  {
    #ifdef RANDOM_SEED
            random_device rd;           // real random number generator to seed the pseudo random number generator
            unsigned seed = rd();
    #else
            unsigned seed = 1;
    #endif
            mt = mt19937(seed);
            randfloat = uniform_real_distribution<Float>(0.0 , 1.0);           // to get [0,1)-uniformly distributed float random numbers out of mb
            randdouble = uniform_real_distribution<double>(0.0 , 1.0);        // to get [0,1)-uniformly distributed double random numbers out of mb
            gaussfloat = normal_distribution<Float>(0.0,1.0);
            count = 0;
        }
    
    inline Float UnifRand()           // creates a [0,1)-uniform random number
    {
        return randfloat(mt);
    //    return rand() / (RAND_MAX+1.0);     // write 1.0 instead of 1 to convert result of addition and division to double
    }

    inline Float GaussRand()           // creates a standard normal distribution
    {
        return gaussfloat(mt);
        //    return rand() / (RAND_MAX+1.0);     // write 1.0 instead of 1 to convert result of addition and division to double
    }

    inline short ChooseInd(short N)     // randomly & uniformly picks an integer number between 0 and N-1 (using the [0,1) unif random number r) that can be used as an index for an array or vector of dimension N
    {
        // use static variables r that stores the random number and count that counts how often the random number has already been used here. Only after every 7th time create a new random number (7 doesn't have a special meaning despite it's the virgin number and the number of capital sins and virtues).
        
        if (count==0)
            r = randdouble(mt);
        if (++count > 7)
            count = 0;
       //     r = rand() / (RAND_MAX+1.0);
        
        short s = short(r * N);
        r = (r * N) - s;                      // reset the class's random number r for the next call of ChooseInd thus avoiding to constantly create a new random number with UniRand()
        return s;
        
    //    std::uniform_int_distribution<> randint(0, N);
    //    return randint(mt);
    }

    // chooses an index respecting the weights by using the rejection method. Needs the maximum weight as input. Use this if the weights are slightly different but not too different and the maximum weight is known.
    template<class InputIterator, class T>
    inline short ChooseInd_respective_weights_rejection_method(InputIterator first, InputIterator last, T max_weight)
    {
        int num_elems = last-first;
        while(true)  {
            short ind = ChooseInd(num_elems);
            if(UnifRand()*max_weight <= *(first+ind))
                return ind;
        }
    }

    // chooses an index respecting the weights using usual search through the vector. Use this if the weights are very different
    template<class InputIterator>
    inline short ChooseInd_respective_weights(InputIterator first, InputIterator last)
    {
        typedef typename remove_reference<decltype(*first)>::type T;   // analogously: typedef typename decay<decltype(*first)>::type T;   // works only for default constructable types; otherwise use decltype(**(InputIterator*)0) or better decltype(*declval<InputIterator>()) from <utility>
        T sum = accumulate(first, last, T(0));
        if (sum==T(0))
            return T(-1);
    REPEAT:
        Float d = UnifRand()*sum;
        for(InputIterator it = first; it!=last; ++it)  {
            if (d < *it)
                return it-first;
            else
                d -= *it;
        }
        goto REPEAT;        // if an element could not be found because sum is slightly greater than the real sum of the elements (due to numerical errors in the continuous update) and d is chosen very large (and also due to rounding errors from double precision UnifRand to single precision), repeat the selection preocedure with a new random number.
    }

    template<class InputIterator, class T>
    inline short ChooseInd_respective_weights(InputIterator first, InputIterator last, T sum)
    {
        if (sum==T(0))
            return T(-1);
    REPEAT:
        Float d = UnifRand()*sum;
        for(InputIterator it = first; it!=last; ++it)  {
            if (d < *it)
                return it-first;
            else
                d -= *it;
        }
        goto REPEAT;     // if an element could not be found because sum is slightly greater than the real sum of the elements (due to numerical errors in the continuous update) and d is chosen very large (and also due to rounding errors from double precision UnifRand to single precision), repeat the selection procedure with a new random number.
    }
};


template<class T>     // Gillespie container for efficient implementation of events that can be grouped into few different groups of events with identical rates. T is the data type of the rates
struct Gillespie_groups_constant_rates  {
    vector<vector<int>> events;
    vector<T> rates;
    vector<T> total_rates;
    int reserve_size;
    
    short rate2type(T rate)    {
        for(short i=0; i<rates.size(); ++i)
            if(rates[i]==rate)
                return i;
        rates.push_back(rate);     // if a type with this rate does not yet exist create a new type; therefore push back all vectors
        total_rates.push_back(0);
        events.push_back({});
        events.back().reserve(reserve_size);
        return rates.size()-1;
    }
    void add_event(int event, T rate)  {
        if(rate==T(0))
            return;
        short type = rate2type(rate);
        events[type].push_back(event);
        //   total_rates[type] += rate;
        total_rates[type] = events[type].size() * rate;
    }
    void remove_event(int event, T rate)  {
        if(rate==T(0))
            return;
        short type = rate2type(rate);
        VecDel_element(events[type], event);
        //   total_rates[type] -= rate;
        total_rates[type] = events[type].size() * rate;
    }
    void remove_index(int ind, short type)  {
    //    short type = rate2type(rate);
        VecDel_index(events[type], ind);
        total_rates[type] -= rates[type];
    }
    int choose_event(bool REMOVE, RandonNumberGenerator& rng)  {
        T total_rate = get_total_rate();
        short type = rng.ChooseInd_respective_weights(total_rates.begin(), total_rates.end(), total_rate);
        int ind = rng.ChooseInd(events[type].size());
        int event = events[type][ind];
        if(REMOVE)
            remove_index(ind,type);
        return event;
    }
    void change_rate(int event, T old_rate, T new_rate)  {
        if(old_rate!=new_rate)  {
            remove_event(event, old_rate);
            add_event(event, new_rate);
        }
    }
    operator vector<int>()  {        // type-cast operator to easily cast all events into a single vector
        vector<int> vec;
        for(short i=0; i<rates.size(); ++i)
            vec.insert(vec.end(),events[i].begin(),events[i].end());
        return vec;
    }
//    void convert_to(vector<int>& vec)  {     // copies all events into the vector vec
//        vec.clear();
//        for(short i=0; i<rates.size(); ++i)
 //           vec.insert(vec.end(),events[i].begin(),events[i].end());
  //  }
    void reserve(int reserve_size_)  {
        reserve_size = reserve_size_;
    }
    T get_total_rate()  {
        return accumulate(total_rates.begin(),total_rates.end(),T(0));
    }
    int get_num_events()  {
        int num_events=0;
        for(vector<int>& vec : events)
            num_events += vec.size();
        return num_events;
    }
};


template<class T, class predicate>     // Gillespie container for efficient implementation of events that can be grouped into few different groups of events with similar rates. Event selection within a group then happens efficiently via the rejection method. (If the rates in each group are identical rather use 'Gillespie_constant_rates'). T is the data type of the rates. A function pointer 'cross_ref' can be given as argument that can be used to create and update corssreferences to the type and index of the events automatically when a new event is created or a rate is being changed. These crossreferences can in turn be used to find events in constant time via their index rather than by searching the whole vector for the respective event. Events with rate 0 are not saved explicitly; the crossreferenced type and index are set to -1.
struct Gillespie_groups_similar_rates  {
    vector<vector<int>> events;
    vector<vector<T>> rates;
    vector<T> maximal_rates;
    vector<T> total_rates;
    vector<T> rate_discrimination;
    
    void set_grouping(const vector<T>& rate_discrimination_, int reserve_size)  {
        rate_discrimination = rate_discrimination_;
        short len = rate_discrimination_.size();
        maximal_rates.resize(len,T(0));
        total_rates.resize(len,T(0));
        events.resize(len);
        rates.resize(len);
        for(short i=0; i<len; ++i)  {     // reserve space for 'reserve_size' events for each type
            events[i].reserve(reserve_size);
            rates[i].reserve(reserve_size);
        }
    }
    short rate2type(T rate)    {
        for(short i=0; i<rate_discrimination.size(); ++i)
            if(rate>=rate_discrimination[i])
                return i;
        if(rate==T(0))
            return -1;
        else
            abort();     // if the event could not be assigned to a group, abort.
    }
    void add_event(int event, T rate, predicate cross_ref)  {      // cross_ref is a function (pointer) or lambda that takes the arguments event, type, and index in the group vector to update any cross reference to 'event' to its assigned type and index in the group vector.
        if(rate==T(0))   {
            cross_ref(event,-1,-1);
            return;
        }
        short type = rate2type(rate);
        events[type].push_back(event);
        rates[type].push_back(rate);
        total_rates[type] += rate;
        if(rate>maximal_rates[type])       // update maximal rate if necessary
            maximal_rates[type] = rate;
        cross_ref(event,type,events[type].size()-1);
    }
    void remove_event(int event, T rate, predicate cross_ref)  {
        if(rate==T(0))
            return;
        short type = rate2type(rate);
        int ind = VecDel_element(events[type], event);
        VecDel_index(rates[type], ind);
        //   total_rates[type] -= rate;
        total_rates[type] -= rate;
    }
    void remove_event(short type, int ind, predicate cross_ref)  {
        if(type==-1)
            return;
        total_rates[type] -= rates[type][ind];
        VecDel_index(events[type], ind);
        VecDel_index(rates[type], ind);
        if(ind<events[type].size())     // do not update the crossreference of the shifted last entry if the deleted event itslef was at the last position
            cross_ref(events[type][ind],type,ind);
    }
    void change_rate(int event, short type, int ind, T new_rate, predicate cross_ref)  {
        T old_rate = (type==-1)  ?  T(0) : rates[type][ind];
        if(old_rate==new_rate)     // case 1: rate does not change
            return;
        else if(type==rate2type(new_rate))  {     // case 2: rate changes but type doesn't change: update rate, total_rate and maximal_rate
            total_rates[type] += new_rate - old_rate;
            if(new_rate>maximal_rates[type])
                maximal_rates[type] = new_rate;
            rates[type][ind] = new_rate;
        }
        else  {      // case 3: rate and type changes; remove and newly add the event
            add_event(event, new_rate, cross_ref);
            remove_event(type, ind, cross_ref);
        }
    }
    int choose_event(RandonNumberGenerator& rng)  {
        T total_rate = get_total_rate();
        short type = rng.ChooseInd_respective_weights(total_rates.begin(), total_rates.end(), total_rate);
        int ind = rng.ChooseInd_respective_weights_rejection_method(rates[type].begin(), rates[type].end(), maximal_rates[type]);
        return events[type][ind];
    }
    void events2vec(vector<int>& vec)  {        // type-cast operator to easily cast all events into a single vector
        for(short i=0; i<events.size(); ++i)
            vec.insert(vec.end(),events[i].begin(),events[i].end());
    }
    void rates2vec(vector<T>& vec)  {        // type-cast operator to easily cast all events into a single vector
        for(short i=0; i<rates.size(); ++i)
            vec.insert(vec.end(),rates[i].begin(),rates[i].end());
    }
    T get_total_rate()  {
        return accumulate(total_rates.begin(),total_rates.end(),T(0));
    }
    void recalculate_total_rates()   {     // recalculate the total rates after several iterations to avoid numerical inaccuracy due to repeated updating of the total_rates. Recalculate maximal rates since by add_event and change_rate these are only increased but never decreased.
        for(short i=0; i<total_rates.size(); ++i)  {
            total_rates[i] = accumulate(rates[i].begin(), rates[i].end(), T(0));
            maximal_rates[i] = *(max_element(rates[i].begin(), rates[i].end()));
        }
    }
    void clear()  {
        for(short i=0; i<rate_discrimination.size(); ++i)  {
            events[i].clear();
            rates[i].clear();
            maximal_rates[i] = T(0);
            total_rates[i] = T(0);
        }
    }
};



#endif
