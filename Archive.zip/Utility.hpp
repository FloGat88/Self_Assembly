//
//  Utility.hpp
//  Self_Assembly
//
//  Created by Florian Gartner on 22/12/16.
//  Copyright © 2016 Florian Gartner. All rights reserved.



#ifndef Utility_hpp
#define Utility_hpp

#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>



using namespace std;

// define a Macro that serves as Tic Toc Token equivalently to that of Matlab
#define _TIC_ auto begin = std::chrono::high_resolution_clock::now()
#define _TOC_ auto end = std::chrono::high_resolution_clock::now(); std::cout << std::chrono::duration_cast<std::chrono::microseconds>(end-begin).count()*1.0e-6 << "sec" << std::endl

template<class T>          // implements the Heaviside step function
float Heaviside(T x) {
    return x<=(T)0 ? 0. : 1.;
}

template<class ForwardIterator>        // return iterator to the smallest nonzero element in the range. If all elements are zero return iterator to the first 0 element in the vector.
ForwardIterator nonzero_min(ForwardIterator first, ForwardIterator last)  {
    if (first==last) return last;
    ForwardIterator smallest = first;
    
    while (++first!=last)
        if (*first<*smallest && *first!=0)    // or: if (comp(*first,*smallest)) for version (2)
            smallest=first;
    return smallest;
}

template<class T>        // exchanges the first val_old it finds in vector vec with val_new; direction indicates the search direction (begin to end or vice versa) 
void exchange_in_vec(vector<T>& vec, const T& val_old, const T& val_new, const short direction=1)  {
    auto it = direction==1 ? vec.begin() : vec.end()-1;        // start value of iterator
    auto it_stop = direction==1 ? vec.end() : vec.begin()-1;    // stop value of iterator
    for( ; it!=it_stop; it+=direction) {
        if(*it==val_old)  {
            *it=val_new;
            return;
        }
    }
    abort();
}



template<class T>
int VecDel_element(vector<T>& vec, const T& val)          // VectorDelete: in vector vec find (the last) element that is identical to val and delete it, i.e. transfer the last vector element on its position and pop_back; return the index of the element deleted
{
    typename vector<T>::iterator it;
    it = vec.end()-1;
    while (it>=vec.begin() && *it != val)                              // search vector from behind until we find an element that is identical to val
        --it;
    
    if(it<vec.begin()) {        // !!! Control mechanism: to be removed later !!!
//        cout << "Element not found in vec by VecDel_element" << endl;      // do not use this if LINEAR_ASSEMBLY==true or generally if it might happen that VecDel_element cannot find the element
        return -1;
    }
    else {
    //    if(it!=vec.end()-1)                     // transfer last element to that position (if it is not the last position anyways).
        *it = vec.back();     // transfer last element to that position and delete last element via pop_back
        vec.pop_back();
        return it-vec.begin();
    }
}

template<class T>
void VecDel_element_all(vector<T>& vec, const T& val, short count=-1)          // VectorDelete: in vector vec find the last 'count' elements that are identical to val and delete them (per default delete all elements val that appear in vec). In order to delete, transfer the last vector element on the position of the to-be-deleted element and pop_back; start iterator from behind (vec.end()) since vec.end() can change during the function if entries are deleted but vec.begin() is fixed.
{
    typename vector<T>::iterator it;
    it = vec.end()-1;
    for(it = vec.end()-1; it>=vec.begin(); --it)  {
        if(*it == val) {
            *it = vec.back();       // transfer last element to the position to be deleted
            vec.pop_back();         // delete last element via pop_back
            if(--count==0)
                return;
        }
    }
}


template<class T>
void VecDel_index(vector<T>& vec, int index)
{
    vec[index] = vec.back();
    vec.pop_back();                         // delete last element via pop_back
}

// container that keeps elements at a constant position (constant index) so that a reference from extern does not have to altered if elements are removed or added to the container. Provides functions for the efficient administration of its elements.
template<class T>
struct ConstPos
{
    vector<T> data;
    vector<int> empty;
    T empty_entry;
    
    ConstPos(const T empty_entry, size_t space) : empty_entry(empty_entry)  {
        data.reserve(space);
        empty.reserve(space);
    }
    /*
    size_t add(const T& val) {
        if(empty.size()>0)  {
            size_t index = empty.back();
            data[index]=val;
            empty.pop_back();
            return index;
        }
        else {
            data.push_back(val);
            return data.size()-1;
        }
    }
    */
    size_t add() {       // only provide a new position in ConstPos (that might be set to) without initializing it
        if(empty.size()>0)  {
            size_t index = empty.back();
            empty.pop_back();
            return index;
        }
        else {
            data.push_back(empty_entry);
            return data.size()-1;
        }
    }
    void Delete(int index) {
        if(index==data.size())
            data.pop_back();
        else {
            data[index] = empty_entry;
            empty.push_back(index);
        }
    }
    void release(int index) {
            empty.push_back(index);
    }
    T& operator[] (int index) {
        return data[index];
    }
    typename vector<T>::iterator begin() {
        return data.begin();
    }
    typename vector<T>::iterator end() {
        return data.end();
    }
    int size() {
        return data.size();
    }
    int content()  {          // returns number of non empty elements in data
        return data.size() - empty.size();
    }
    void clear()  {
        data.clear();
        empty.clear();
    }
};


template <typename T>           // implements += for vectors; both vectors must be of the same size!
std::vector<T>& operator+=(std::vector<T>& a, const std::vector<T>& b)
{
    if(a.size() != b.size())
        abort();
    
    std::transform(a.begin(), a.end(), b.begin(),
                   a.begin(), std::plus<T>());
    return a;
};


template <class T>              // overload "+" for all vector and array types etc.
T operator+(const T& a1, const T& a2)
{
    T a;
    for (typename T::size_type i = 0; i < a1.size(); i++)
        a[i] = a1[i] + a2[i];
    return a;
};


#endif /* Utility_hpp */
